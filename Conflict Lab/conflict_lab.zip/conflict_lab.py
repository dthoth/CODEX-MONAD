#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         C O N F L I C T   L A B                              ║
║                    Integrated Geopolitical Analysis Engine                   ║
║                              Version 2.0                                     ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  THREE-LAYER ANALYTICAL FRAMEWORK:                                           ║
║                                                                              ║
║  LAYER 1: SYSTEMIC VARIABLES (Forest Level)                                  ║
║    Demographics, economics, information topology, social cohesion,           ║
║    historical memory. The structural kindling that determines IF             ║
║    revolution is possible and HOW FAST it can spread.                        ║
║                                                                              ║
║  LAYER 2: REVOLUTION DYNAMICS (Fire Level)                                   ║
║    Regime state, revolutionary movement, external actors.                    ║
║    The active combustion - defection probabilities, cascade speeds,          ║
║    violence forecasts, timeline estimates.                                   ║
║                                                                              ║
║  LAYER 3: SYSTEM STATE (Meta-Pattern Level)                                  ║
║    Solve et Coagula forcing function. Proxy network dissolution,             ║
║    actor revelation pressure, architecture crystallization.                  ║
║    The invisible hand shaping regional transformation.                       ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  METHODOLOGY NOTES:                                                          ║
║                                                                              ║
║  The "humans trap": Watching news shows people doing things, naturally       ║
║  model as intentions/decisions/personalities. But at system scale,           ║
║  humans execute patterns they can't see consciously. They think they're      ║
║  choosing but responding to gradients they don't perceive.                   ║
║                                                                              ║
║  Example: 22-year-old Iranian woman doesn't know she's part of               ║
║  demographic bulge making revolution statistically inevitable given          ║
║  regime resource constraints. She just knows she's angry and not afraid.     ║
║                                                                              ║
║  SOLVE ET COAGULA PATTERN:                                                   ║
║  1. COAGULA (Crystallize): Force distributed actors to reveal positions      ║
║  2. SOLVE (Dissolve): Now visible structures can be dissolved                ║
║  3. COAGULA (Reconstitute): New architecture crystallizes                    ║
║                                                                              ║
║  "You can't dissolve what you can't see. The forcing function made them      ║
║  visible FIRST, then dissolvable."                                           ║
║                                                                              ║
╠══════════════════════════════════════════════════════════════════════════════╣
║  Built: January 2026 during live Iran Revolution analysis                    ║
║  Framework: Simbell Trust Consulting                                         ║
╚══════════════════════════════════════════════════════════════════════════════╝
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Any
from enum import Enum
from datetime import datetime
import random
import math
import json
import os

# =============================================================================
# ENUMS AND CONSTANTS
# =============================================================================

class SystemPhase(Enum):
    """Solve et Coagula phases"""
    COAGULA_1 = "crystallize_opposition"    # Force actors to reveal
    SOLVE = "dissolve"                       # Dissolve revealed structures
    COAGULA_2 = "reconstitute"              # New architecture forms

class CleavageType(Enum):
    """Types of social divisions"""
    ETHNIC = "ethnic"
    RELIGIOUS = "religious"
    LINGUISTIC = "linguistic"
    REGIONAL = "regional"
    CLASS = "class"
    URBAN_RURAL = "urban_rural"
    GENERATIONAL = "generational"
    TRIBAL = "tribal"

# Key thresholds discovered through modeling
THRESHOLDS = {
    'fear_crossing': 0.65,           # Population fear level below which cascade begins
    'defection_critical': 0.50,      # Security force loyalty below which regime doomed
    'cascade_acceleration': 1.5,     # Cascade speed above which outcome inevitable
    'resource_crisis': 0.30,         # Economic resources below which can't pay forces
    'legitimacy_collapse': 0.20,     # Legitimacy below which no recovery possible
}


# =============================================================================
# LAYER 1: SYSTEMIC VARIABLES (FOREST LEVEL)
# =============================================================================

@dataclass
class DemographicProfile:
    """Demographics are destiny - especially for revolutions."""
    population_total: int
    median_age: float
    age_0_14: float
    age_15_24: float          # CRITICAL: Revolution fuel age bracket
    age_25_54: float
    age_55_plus: float
    urbanization_rate: float
    urbanization_trend: float
    capital_city_concentration: float
    literacy_rate: float
    university_enrollment_rate: float
    university_graduates_annual: int
    female_labor_participation: float
    gender_education_gap: float
    net_migration_rate: float
    diaspora_size: int
    diaspora_as_pct_of_population: float
    
    @property
    def youth_bulge_ratio(self) -> float:
        """High ratio (>0.35) = revolution fuel"""
        adult_pop = self.age_15_24 + self.age_25_54 + self.age_55_plus
        youth_29 = self.age_15_24 + (self.age_25_54 * 0.2)
        return youth_29 / adult_pop if adult_pop > 0 else 0
    
    def get_instability_score(self) -> float:
        youth_pressure = min(1.0, self.youth_bulge_ratio / 0.4)
        urban_pressure = self.urbanization_rate
        education_pressure = self.university_enrollment_rate
        gender_pressure = 1.0 - self.female_labor_participation
        return (youth_pressure * 0.35 + urban_pressure * 0.25 + 
                education_pressure * 0.25 + gender_pressure * 0.15)
    
    def get_coordination_capacity(self) -> float:
        return (self.literacy_rate * 0.4 + self.urbanization_rate * 0.4 + 
                self.capital_city_concentration * 0.5 * 0.2)


@dataclass
class EconomicProfile:
    """Economic structure determines who has stake in status quo vs change."""
    gdp_total_usd: float
    gdp_per_capita_usd: float
    gdp_growth_rate: float
    gdp_growth_trend: str
    gini_coefficient: float
    poverty_rate: float
    wealth_top_10_pct: float
    unemployment_rate: float
    youth_unemployment_rate: float    # CRITICAL
    underemployment_rate: float
    public_sector_employment_pct: float
    informal_economy_pct: float
    remittance_pct_of_gdp: float
    oil_gas_pct_of_gdp: float
    oil_gas_pct_of_exports: float
    oil_gas_pct_of_govt_revenue: float
    under_sanctions: bool
    sanctions_severity: float
    trade_openness: float
    inflation_rate: float
    currency_stability: float
    
    @property
    def resource_curse_index(self) -> float:
        return (self.oil_gas_pct_of_gdp * 0.3 + self.oil_gas_pct_of_exports * 0.3 + 
                self.oil_gas_pct_of_govt_revenue * 0.4)
    
    def get_economic_grievance_score(self) -> float:
        unemployment_pressure = self.youth_unemployment_rate
        inequality_pressure = self.gini_coefficient
        poverty_pressure = self.poverty_rate
        inflation_pressure = min(1.0, self.inflation_rate / 50)
        return (unemployment_pressure * 0.35 + inequality_pressure * 0.25 +
                poverty_pressure * 0.25 + inflation_pressure * 0.15)
    
    def get_state_economic_control(self) -> float:
        public_employment = self.public_sector_employment_pct
        formal_economy = 1.0 - self.informal_economy_pct
        low_remittance = 1.0 - min(1.0, self.remittance_pct_of_gdp / 20)
        return (public_employment * 0.4 + formal_economy * 0.35 + low_remittance * 0.25)
    
    def get_regime_fiscal_health(self) -> float:
        growth_factor = max(0, min(1, (self.gdp_growth_rate + 5) / 15))
        sanctions_impact = 1.0 - (self.sanctions_severity * 0.5 if self.under_sanctions else 0)
        currency_factor = self.currency_stability
        return (growth_factor * 0.4 + sanctions_impact * 0.35 + currency_factor * 0.25)


@dataclass
class InformationProfile:
    """How does information flow? Determines preference cascade speed."""
    internet_penetration: float
    smartphone_penetration: float
    social_media_users_pct: float
    primary_platforms: List[str]
    vpn_usage_estimate: float
    internet_freedom_score: float
    social_media_blocked: List[str]
    state_surveillance_capacity: float
    content_filtering_sophistication: float
    state_media_dominance: float
    independent_media_exists: bool
    foreign_media_access: float
    journalist_safety_index: float
    diaspora_media_influence: float
    diaspora_communication_channels: List[str]
    word_of_mouth_reliance: float
    mosque_church_network_strength: float
    bazaar_market_network_strength: float
    
    def get_horizontal_communication_capacity(self) -> float:
        digital = (self.internet_penetration * 0.3 + self.smartphone_penetration * 0.4 +
                   self.vpn_usage_estimate * 0.3)
        traditional = (self.word_of_mouth_reliance * 0.4 +
                       self.mosque_church_network_strength * 0.3 +
                       self.bazaar_market_network_strength * 0.3)
        state_repression = 1.0 - self.internet_freedom_score
        return digital * (1 - state_repression * 0.3) + traditional * state_repression * 0.5
    
    def get_cascade_speed_multiplier(self) -> float:
        base = self.get_horizontal_communication_capacity()
        smartphone_boost = 1.0 + (self.smartphone_penetration * 0.5)
        diaspora_boost = 1.0 + (self.diaspora_media_influence * 0.3)
        control_drag = 1.0 - (self.state_surveillance_capacity * 0.3)
        return base * smartphone_boost * diaspora_boost * control_drag


@dataclass
class SocialCleavage:
    """A specific social division that can be activated"""
    cleavage_type: CleavageType
    groups: List[str]
    dominant_group: str
    dominant_group_pct: float
    tension_level: float
    historical_violence: bool
    currently_politicized: bool
    activation_energy: float


@dataclass
class SocialCohesionProfile:
    """What holds this society together? What could tear it apart?"""
    ethnic_fractionalization: float
    religious_fractionalization: float
    linguistic_fractionalization: float
    interpersonal_trust: float
    institutional_trust: float
    military_trust: float
    police_trust: float
    national_identity_strength: float
    subnational_identity_strength: float
    civil_society_strength: float
    union_membership_rate: float
    religious_organization_membership: float
    ngo_density: float
    years_as_unified_state: int
    colonial_history: bool
    colonial_borders_artificial: bool
    cleavages: List[SocialCleavage] = field(default_factory=list)
    
    def get_fragmentation_risk(self) -> float:
        base_frac = (self.ethnic_fractionalization * 0.35 +
                     self.religious_fractionalization * 0.35 +
                     self.linguistic_fractionalization * 0.15 +
                     (1.0 - self.national_identity_strength) * 0.15)
        active_cleavages = sum(1 for c in self.cleavages if c.currently_politicized)
        violent_history = sum(1 for c in self.cleavages if c.historical_violence)
        cleavage_boost = min(0.3, active_cleavages * 0.1 + violent_history * 0.05)
        return min(1.0, base_frac + cleavage_boost)
    
    def get_collective_action_capacity(self) -> float:
        trust_factor = (self.interpersonal_trust * 0.5 + self.institutional_trust * 0.2 +
                        self.military_trust * 0.3)
        civil_society = (self.civil_society_strength * 0.4 +
                         self.religious_organization_membership * 0.3 +
                         self.union_membership_rate * 0.3)
        return (trust_factor * 0.35 + civil_society * 0.35 + self.national_identity_strength * 0.3)


@dataclass
class HistoricalEvent:
    """A historical event that shapes collective memory"""
    name: str
    year: int
    event_type: str
    outcome: str
    casualties: int
    in_living_memory: bool
    narrative_strength: float


@dataclass
class HistoricalMemoryProfile:
    """What does this society remember? Shapes what people think is possible."""
    previous_revolutions: List[HistoricalEvent] = field(default_factory=list)
    years_since_last_revolution: Optional[int] = None
    last_revolution_outcome: Optional[str] = None
    regime_founding_event: Optional[HistoricalEvent] = None
    regime_age_years: int = 0
    regime_type_changes: int = 0
    collective_trauma_events: List[HistoricalEvent] = field(default_factory=list)
    martyr_mythology_strength: float = 0.5
    notable_martyrs: List[str] = field(default_factory=list)
    martyr_commemoration_active: bool = False
    generational_narrative_gap: float = 0.5
    founding_generation_alive: bool = True
    inspiring_revolutions: List[str] = field(default_factory=list)
    cautionary_revolutions: List[str] = field(default_factory=list)
    
    def get_revolutionary_precedent_score(self) -> float:
        successful = sum(1 for r in self.previous_revolutions 
                         if r.outcome == 'success' and r.in_living_memory)
        failed = sum(1 for r in self.previous_revolutions 
                     if r.outcome == 'failure' and r.in_living_memory)
        inspiring = len(self.inspiring_revolutions) * 0.1
        cautionary = len(self.cautionary_revolutions) * 0.05
        base = 0.3
        success_boost = min(0.4, successful * 0.2)
        failure_drag = failed * 0.1
        external = inspiring - cautionary
        return min(1.0, max(0.0, base + success_boost - failure_drag + external))
    
    def get_fear_of_chaos_score(self) -> float:
        traumatic = sum(1 for t in self.collective_trauma_events 
                        if t.event_type in ['civil_war', 'massacre', 'famine'] 
                        and t.in_living_memory)
        cautionary = len(self.cautionary_revolutions)
        regional_chaos_examples = cautionary * 0.15
        trauma_factor = min(0.5, traumatic * 0.15)
        return min(1.0, 0.2 + trauma_factor + regional_chaos_examples)
    
    def get_martyr_effect_multiplier(self) -> float:
        base = self.martyr_mythology_strength
        if self.martyr_commemoration_active:
            base *= 1.3
        return base


@dataclass
class CountrySystemicProfile:
    """Complete systemic profile - the forest-level view."""
    name: str
    iso_code: str
    demographics: DemographicProfile
    economics: EconomicProfile
    information: InformationProfile
    social: SocialCohesionProfile
    history: HistoricalMemoryProfile
    last_updated: str
    data_quality: float
    
    def calculate_structural_instability(self) -> float:
        demographic_pressure = self.demographics.get_instability_score()
        economic_grievance = self.economics.get_economic_grievance_score()
        coordination_capacity = self.information.get_cascade_speed_multiplier()
        collective_action = self.social.get_collective_action_capacity()
        revolutionary_precedent = self.history.get_revolutionary_precedent_score()
        return (demographic_pressure * 0.25 + economic_grievance * 0.25 +
                coordination_capacity * 0.15 + collective_action * 0.15 +
                revolutionary_precedent * 0.20)
    
    def calculate_regime_structural_strength(self) -> float:
        economic_control = self.economics.get_state_economic_control()
        fiscal_health = self.economics.get_regime_fiscal_health()
        surveillance = self.information.state_surveillance_capacity
        low_fragmentation = 1.0 - self.social.get_fragmentation_risk()
        fear_of_chaos = self.history.get_fear_of_chaos_score()
        return (economic_control * 0.25 + fiscal_health * 0.25 + surveillance * 0.20 +
                low_fragmentation * 0.15 + fear_of_chaos * 0.15)
    
    def calculate_cascade_potential(self) -> float:
        cascade_speed = self.information.get_cascade_speed_multiplier()
        coordination = self.demographics.get_coordination_capacity()
        martyr_effect = self.history.get_martyr_effect_multiplier()
        generational_break = self.history.generational_narrative_gap
        return (cascade_speed * 0.35 + coordination * 0.25 +
                martyr_effect * 0.20 + generational_break * 0.20)
    
    def calculate_fragmentation_risk(self) -> float:
        social_frag = self.social.get_fragmentation_risk()
        fear_of_chaos = self.history.get_fear_of_chaos_score()
        return social_frag * 0.7 + (1.0 - fear_of_chaos) * 0.3
    
    def get_full_assessment(self) -> Dict:
        return {
            'name': self.name,
            'structural_instability': round(self.calculate_structural_instability(), 3),
            'regime_structural_strength': round(self.calculate_regime_structural_strength(), 3),
            'cascade_potential': round(self.calculate_cascade_potential(), 3),
            'fragmentation_risk': round(self.calculate_fragmentation_risk(), 3),
            'net_instability': round(
                self.calculate_structural_instability() - 
                self.calculate_regime_structural_strength(), 3
            ),
            'components': {
                'demographic_pressure': round(self.demographics.get_instability_score(), 3),
                'economic_grievance': round(self.economics.get_economic_grievance_score(), 3),
                'coordination_capacity': round(self.demographics.get_coordination_capacity(), 3),
                'cascade_speed': round(self.information.get_cascade_speed_multiplier(), 3),
                'collective_action': round(self.social.get_collective_action_capacity(), 3),
                'revolutionary_precedent': round(self.history.get_revolutionary_precedent_score(), 3),
                'fear_of_chaos': round(self.history.get_fear_of_chaos_score(), 3),
                'martyr_multiplier': round(self.history.get_martyr_effect_multiplier(), 3),
            }
        }


# =============================================================================
# LAYER 2: REVOLUTION DYNAMICS (FIRE LEVEL)
# =============================================================================

@dataclass
class RegimeState:
    """Current state of the regime under pressure"""
    name: str
    leader: str
    regime_type: str
    legitimacy: float
    economic_resources: float
    security_force_loyalty: float
    elite_cohesion: float
    international_support: float
    information_control: float
    territorial_control: float
    succession_clarity: float
    ideological_commitment: float
    foreign_militia_deployed: bool = False
    internet_shutdown_active: bool = False
    martial_law_declared: bool = False
    mass_arrests_ongoing: bool = False


@dataclass
class RevolutionState:
    """Current state of revolutionary movement"""
    name: str
    active_protesters: int
    total_sympathizers: int
    organization_level: float
    leadership_identified: bool
    leadership_names: List[str]
    unified_demands: bool
    primary_demands: List[str]
    geographic_spread: float
    cross_class_coalition: bool
    cross_ethnic_coalition: bool
    armed_component: bool
    international_support: float
    diaspora_support: float
    martyrs_count: int
    fear_threshold_crossed: bool
    momentum: float


@dataclass
class ExternalActors:
    """External forces affecting the conflict"""
    us_support_level: float
    us_sanctions_active: bool
    us_rhetorical_support: bool
    us_actual_intervention: bool
    regional_power_support: float
    regional_power_opposition: float
    un_involvement: float
    diaspora_funding: float
    foreign_media_coverage: float
    neighboring_country_spillover: float
    great_power_competition_factor: float


# =============================================================================
# LAYER 3: SYSTEM STATE (META-PATTERN LEVEL)
# =============================================================================

@dataclass
class ProxyNetworkStatus:
    """Tracks dissolution of proxy networks"""
    name: str
    status: str  # 'active', 'degraded', 'fragmenting', 'isolated', 'dissolved'
    remaining_capacity: float
    sponsor: str
    dissolution_date: Optional[str] = None


@dataclass
class ActorRevelation:
    """Tracks how much each actor has been forced to reveal"""
    name: str
    position: str  # 'aligned', 'hedging', 'revealed_opposition', 'revealed_aligned'
    revelation_complete: float
    chose_side: Optional[str] = None
    leverage_remaining: float = 1.0
    adaptation_lag: int = 0


@dataclass
class DomesticFlankStatus:
    """Tracks domestic opposition containment"""
    country: str
    protest_networks_mapped: bool
    legal_framework_established: bool
    enforcement_demonstrated: bool
    external_amplification_blocked: bool


@dataclass
class ArchitectureNode:
    """Tracks new regional architecture crystallization"""
    name: str
    status: str  # 'founding', 'active', 'pending', 'refused'
    integration_depth: float
    economic_ties: float
    security_ties: float
    joined_date: Optional[str] = None


@dataclass
class ForcingFunction:
    """The meta-layer: Solve et Coagula system state tracking"""
    current_phase: SystemPhase
    phase_start_date: str
    proxy_networks: Dict[str, ProxyNetworkStatus] = field(default_factory=dict)
    revealed_actors: Dict[str, ActorRevelation] = field(default_factory=dict)
    domestic_flanks: Dict[str, DomesticFlankStatus] = field(default_factory=dict)
    architecture_nodes: Dict[str, ArchitectureNode] = field(default_factory=dict)
    tempo_ooda_advantage: float = 0.0
    
    def calculate_ambiguity_remaining(self) -> float:
        if not self.revealed_actors:
            return 1.0
        total_revelation = sum(a.revelation_complete for a in self.revealed_actors.values())
        return 1.0 - (total_revelation / len(self.revealed_actors))
    
    def calculate_cascade_multiplier(self) -> float:
        dissolved = sum(1 for p in self.proxy_networks.values() if p.status == 'dissolved')
        tempo_boost = 1.0 + (self.tempo_ooda_advantage * 0.1)
        return (1.0 + dissolved * 0.15) * tempo_boost
    
    def calculate_revelation_pressure(self, actor_name: str) -> float:
        if actor_name not in self.revealed_actors:
            return 0.5
        actor = self.revealed_actors[actor_name]
        base_pressure = actor.revelation_complete
        hedging_penalty = 0.2 if actor.position == 'hedging' else 0
        cascade_pressure = self.calculate_cascade_multiplier() * 0.1
        return min(1.0, base_pressure + hedging_penalty + cascade_pressure)
    
    def calculate_onus_position(self) -> Dict:
        dissolved = sum(1 for p in self.proxy_networks.values() if p.status == 'dissolved')
        architecture_momentum = self.calculate_architecture_momentum()
        if dissolved >= 3 and architecture_momentum > 0.7:
            return {'burden_holder': 'holdouts', 'narrative': 'Why resist inevitable transition?'}
        elif dissolved >= 2:
            return {'burden_holder': 'contested', 'narrative': 'Both sides claiming justification'}
        else:
            return {'burden_holder': 'status_quo_challengers', 'narrative': 'Challengers must justify disruption'}
    
    def calculate_architecture_momentum(self) -> float:
        if not self.architecture_nodes:
            return 0.0
        active_nodes = [n for n in self.architecture_nodes.values() if n.status in ['founding', 'active']]
        if not active_nodes:
            return 0.0
        avg_integration = sum(n.integration_depth for n in active_nodes) / len(active_nodes)
        node_count_factor = min(1.0, len(active_nodes) / 6)
        return (avg_integration * 0.6 + node_count_factor * 0.4)


# =============================================================================
# CORE CALCULATION FUNCTIONS
# =============================================================================

def calculate_defection_probability(regime: RegimeState, revolution: RevolutionState) -> float:
    """Probability that security forces start switching sides."""
    base_defection = 1.0 - regime.security_force_loyalty
    if revolution.fear_threshold_crossed:
        base_defection += 0.2
    if revolution.cross_class_coalition and revolution.cross_ethnic_coalition:
        base_defection += 0.15
    if regime.foreign_militia_deployed:
        base_defection += 0.1  # Native forces resent foreigners
    if revolution.martyrs_count > 100:
        base_defection += 0.1
    if regime.economic_resources < 0.3:
        base_defection += 0.15
    if regime.elite_cohesion < 0.5:
        base_defection += 0.1
    return min(0.95, max(0.05, base_defection))


def calculate_preference_cascade_speed(regime: RegimeState, revolution: RevolutionState) -> float:
    """How fast fence-sitters join the revolution."""
    base_speed = 1.0
    if revolution.fear_threshold_crossed:
        base_speed *= 2.0
    if revolution.geographic_spread > 0.7:
        base_speed *= 1.5
    if regime.internet_shutdown_active:
        base_speed *= 0.7  # Slows but doesn't stop
    if revolution.diaspora_support > 0.7:
        base_speed *= 1.3
    if revolution.martyrs_count > 50:
        base_speed *= (1.0 + min(0.5, revolution.martyrs_count / 200))
    base_speed *= (2.0 - regime.information_control)
    return base_speed


def calculate_regime_collapse_probability(
    regime: RegimeState, 
    revolution: RevolutionState,
    external: ExternalActors
) -> float:
    """Master calculation: probability regime collapses."""
    defection_prob = calculate_defection_probability(regime, revolution)
    cascade_speed = calculate_preference_cascade_speed(regime, revolution)
    
    base_collapse = 0.1
    
    # Defection is the killer
    if defection_prob > 0.7:
        base_collapse += 0.5
    elif defection_prob > 0.5:
        base_collapse += 0.3
    elif defection_prob > 0.3:
        base_collapse += 0.15
    
    # Cascade speed accelerates
    if cascade_speed > 2.0:
        base_collapse += 0.2
    elif cascade_speed > 1.5:
        base_collapse += 0.1
    
    # Fear threshold is critical
    if revolution.fear_threshold_crossed:
        base_collapse += 0.15
    
    # Resources
    if regime.economic_resources < 0.2:
        base_collapse += 0.2
    elif regime.economic_resources < 0.4:
        base_collapse += 0.1
    
    # Elite cohesion
    if regime.elite_cohesion < 0.3:
        base_collapse += 0.15
    elif regime.elite_cohesion < 0.5:
        base_collapse += 0.08
    
    # Territorial control
    base_collapse += (1.0 - regime.territorial_control) * 0.3
    
    # External pressure
    if external.us_actual_intervention:
        base_collapse += 0.3
    elif external.us_sanctions_active and external.us_rhetorical_support:
        base_collapse += 0.1
    
    return min(0.99, max(0.01, base_collapse))


def calculate_violence_level(regime: RegimeState, revolution: RevolutionState) -> Tuple[str, float]:
    """Predicts violence level and intensity score."""
    intensity = 0.0
    
    if regime.foreign_militia_deployed:
        intensity += 0.3
    if regime.martial_law_declared:
        intensity += 0.2
    if revolution.armed_component:
        intensity += 0.25
    if regime.security_force_loyalty > 0.8:
        intensity += 0.15  # Will fight hard
    if regime.ideological_commitment > 0.8:
        intensity += 0.1
    
    # Defection reduces violence (negotiated transition)
    defection = calculate_defection_probability(regime, revolution)
    if defection > 0.7:
        intensity *= 0.5
    
    if intensity > 0.7:
        return ("Severe - potential civil war dynamics", intensity)
    elif intensity > 0.5:
        return ("High - significant street violence expected", intensity)
    elif intensity > 0.3:
        return ("Moderate - targeted repression and clashes", intensity)
    else:
        return ("Low - mostly political/economic pressure", intensity)


def estimate_resolution_timeline(
    regime: RegimeState,
    revolution: RevolutionState, 
    external: ExternalActors
) -> Dict:
    """Estimate days to resolution and type of ending."""
    collapse_prob = calculate_regime_collapse_probability(regime, revolution, external)
    cascade_speed = calculate_preference_cascade_speed(regime, revolution)
    defection_prob = calculate_defection_probability(regime, revolution)
    
    if collapse_prob > 0.8:
        days_estimate = random.randint(1, 7)
        ending_type = "Rapid collapse"
    elif collapse_prob > 0.6:
        days_estimate = random.randint(7, 30)
        ending_type = "Accelerating collapse"
    elif collapse_prob > 0.4:
        days_estimate = random.randint(30, 90)
        ending_type = "Grinding attrition"
    else:
        days_estimate = random.randint(90, 365)
        ending_type = "Prolonged struggle or stalemate"
    
    if defection_prob > 0.7:
        days_estimate = int(days_estimate * 0.5)
        ending_type = "Palace coup / security defection"
    
    if external.us_actual_intervention:
        days_estimate = int(days_estimate * 0.3)
        ending_type = "External intervention"
    
    return {
        "days_estimate_low": max(1, int(days_estimate * 0.5)),
        "days_estimate_high": int(days_estimate * 1.5),
        "ending_type": ending_type,
        "collapse_probability": collapse_prob,
        "defection_probability": defection_prob,
        "cascade_speed": cascade_speed,
    }


def apply_system_state_to_collapse(
    base_probability: float,
    country_name: str,
    system_state: ForcingFunction
) -> float:
    """Apply system-level effects to country collapse probability."""
    adjusted = base_probability
    cascade_mult = system_state.calculate_cascade_multiplier()
    
    actor = system_state.revealed_actors.get(country_name)
    
    if actor:
        if actor.chose_side == 'holdout':
            # Holdouts get full cascade effect
            adjusted = adjusted * cascade_mult
            # Plus revelation pressure
            revelation_pressure = system_state.calculate_revelation_pressure(country_name)
            adjusted += revelation_pressure * 0.1
        elif actor.chose_side == 'new_architecture':
            # Aligned actors get stability boost
            architecture_momentum = system_state.calculate_architecture_momentum()
            stability_boost = architecture_momentum * 0.1
            adjusted = max(0.01, adjusted - stability_boost)
        else:
            # Hedging actors get moderate pressure
            adjusted = adjusted * (1 + (cascade_mult - 1) * 0.3)
    
    return min(0.99, max(0.01, adjusted))


# =============================================================================
# COUNTRY PROFILE DATABASE
# =============================================================================

def create_iran_profile() -> CountrySystemicProfile:
    """Iran - January 2026 - Live Revolution"""
    return CountrySystemicProfile(
        name="Iran",
        iso_code="IR",
        demographics=DemographicProfile(
            population_total=88_000_000, median_age=32.0,
            age_0_14=0.24, age_15_24=0.14, age_25_54=0.43, age_55_plus=0.19,
            urbanization_rate=0.76, urbanization_trend=0.012, capital_city_concentration=0.18,
            literacy_rate=0.88, university_enrollment_rate=0.55, university_graduates_annual=500_000,
            female_labor_participation=0.17, gender_education_gap=-0.02,
            net_migration_rate=-0.5, diaspora_size=4_000_000, diaspora_as_pct_of_population=0.045,
        ),
        economics=EconomicProfile(
            gdp_total_usd=388_000_000_000, gdp_per_capita_usd=4_400,
            gdp_growth_rate=-3.0, gdp_growth_trend='falling',
            gini_coefficient=0.42, poverty_rate=0.30, wealth_top_10_pct=0.35,
            unemployment_rate=0.12, youth_unemployment_rate=0.28, underemployment_rate=0.20,
            public_sector_employment_pct=0.25, informal_economy_pct=0.35, remittance_pct_of_gdp=0.01,
            oil_gas_pct_of_gdp=0.20, oil_gas_pct_of_exports=0.70, oil_gas_pct_of_govt_revenue=0.40,
            under_sanctions=True, sanctions_severity=0.85, trade_openness=0.35,
            inflation_rate=45.0, currency_stability=0.2,
        ),
        information=InformationProfile(
            internet_penetration=0.84, smartphone_penetration=0.75, social_media_users_pct=0.65,
            primary_platforms=['telegram', 'instagram', 'whatsapp'], vpn_usage_estimate=0.60,
            internet_freedom_score=0.15, social_media_blocked=['twitter', 'facebook', 'youtube'],
            state_surveillance_capacity=0.7, content_filtering_sophistication=0.6,
            state_media_dominance=0.5, independent_media_exists=False, foreign_media_access=0.6,
            journalist_safety_index=0.1, diaspora_media_influence=0.7,
            diaspora_communication_channels=['telegram', 'signal', 'satellite_tv'],
            word_of_mouth_reliance=0.7, mosque_church_network_strength=0.3, bazaar_market_network_strength=0.8,
        ),
        social=SocialCohesionProfile(
            ethnic_fractionalization=0.47, religious_fractionalization=0.15, linguistic_fractionalization=0.35,
            interpersonal_trust=0.25, institutional_trust=0.15, military_trust=0.25, police_trust=0.10,
            national_identity_strength=0.75, subnational_identity_strength=0.4,
            civil_society_strength=0.2, union_membership_rate=0.1, religious_organization_membership=0.3, ngo_density=0.1,
            years_as_unified_state=2500, colonial_history=False, colonial_borders_artificial=False,
            cleavages=[
                SocialCleavage(CleavageType.GENERATIONAL, ['Pre-revolution', 'Revolution', 'Post-revolution'],
                               'Revolution generation', 0.3, 0.9, False, True, 0.1),
            ],
        ),
        history=HistoricalMemoryProfile(
            previous_revolutions=[
                HistoricalEvent("1979 Islamic Revolution", 1979, "revolution", "success", 3000, True, 0.95),
                HistoricalEvent("2022 Woman Life Freedom", 2022, "revolution", "mixed", 500, True, 0.9),
            ],
            years_since_last_revolution=3, last_revolution_outcome="mixed",
            regime_age_years=46, regime_type_changes=1,
            martyr_mythology_strength=0.85, notable_martyrs=['Mahsa Amini', 'Nika Shakarami'],
            martyr_commemoration_active=True, generational_narrative_gap=0.85, founding_generation_alive=True,
            inspiring_revolutions=['Fall of Berlin Wall', 'Velvet Revolution'],
            cautionary_revolutions=['Syria', 'Libya'],
        ),
        last_updated="2026-01-10", data_quality=0.7,
    )


def create_saudi_profile() -> CountrySystemicProfile:
    """Saudi Arabia - Post-Iran collapse stability"""
    return CountrySystemicProfile(
        name="Saudi Arabia",
        iso_code="SA",
        demographics=DemographicProfile(
            population_total=35_000_000, median_age=31.8,
            age_0_14=0.25, age_15_24=0.13, age_25_54=0.50, age_55_plus=0.12,
            urbanization_rate=0.84, urbanization_trend=0.015, capital_city_concentration=0.20,
            literacy_rate=0.97, university_enrollment_rate=0.60, university_graduates_annual=200_000,
            female_labor_participation=0.33, gender_education_gap=0.05,
            net_migration_rate=2.0, diaspora_size=500_000, diaspora_as_pct_of_population=0.014,
        ),
        economics=EconomicProfile(
            gdp_total_usd=1_100_000_000_000, gdp_per_capita_usd=30_000,
            gdp_growth_rate=4.0, gdp_growth_trend='rising',
            gini_coefficient=0.45, poverty_rate=0.05, wealth_top_10_pct=0.50,
            unemployment_rate=0.11, youth_unemployment_rate=0.25, underemployment_rate=0.15,
            public_sector_employment_pct=0.70, informal_economy_pct=0.10, remittance_pct_of_gdp=0.01,
            oil_gas_pct_of_gdp=0.42, oil_gas_pct_of_exports=0.75, oil_gas_pct_of_govt_revenue=0.60,
            under_sanctions=False, sanctions_severity=0.0, trade_openness=0.65,
            inflation_rate=2.5, currency_stability=0.95,
        ),
        information=InformationProfile(
            internet_penetration=0.98, smartphone_penetration=0.95, social_media_users_pct=0.80,
            primary_platforms=['twitter', 'snapchat', 'instagram', 'tiktok'], vpn_usage_estimate=0.30,
            internet_freedom_score=0.30, social_media_blocked=[],
            state_surveillance_capacity=0.85, content_filtering_sophistication=0.5,
            state_media_dominance=0.6, independent_media_exists=False, foreign_media_access=0.8,
            journalist_safety_index=0.2, diaspora_media_influence=0.3,
            diaspora_communication_channels=['standard platforms'],
            word_of_mouth_reliance=0.4, mosque_church_network_strength=0.7, bazaar_market_network_strength=0.3,
        ),
        social=SocialCohesionProfile(
            ethnic_fractionalization=0.25, religious_fractionalization=0.15, linguistic_fractionalization=0.10,
            interpersonal_trust=0.35, institutional_trust=0.50, military_trust=0.60, police_trust=0.45,
            national_identity_strength=0.70, subnational_identity_strength=0.4,
            civil_society_strength=0.1, union_membership_rate=0.0, religious_organization_membership=0.5, ngo_density=0.05,
            years_as_unified_state=93, colonial_history=False, colonial_borders_artificial=False,
            cleavages=[],
        ),
        history=HistoricalMemoryProfile(
            previous_revolutions=[], years_since_last_revolution=None, last_revolution_outcome=None,
            regime_age_years=93, regime_type_changes=0,
            martyr_mythology_strength=0.3, notable_martyrs=[], martyr_commemoration_active=False,
            generational_narrative_gap=0.4, founding_generation_alive=False,
            inspiring_revolutions=[], cautionary_revolutions=['Syria', 'Libya', 'Yemen', 'Iraq'],
        ),
        last_updated="2026-01-10", data_quality=0.6,
    )


def create_russia_profile() -> CountrySystemicProfile:
    """Russia - Post-Ukraine exhaustion"""
    return CountrySystemicProfile(
        name="Russia",
        iso_code="RU",
        demographics=DemographicProfile(
            population_total=144_000_000, median_age=40.3,
            age_0_14=0.18, age_15_24=0.09, age_25_54=0.44, age_55_plus=0.29,
            urbanization_rate=0.75, urbanization_trend=0.003, capital_city_concentration=0.08,
            literacy_rate=0.99, university_enrollment_rate=0.58, university_graduates_annual=800_000,
            female_labor_participation=0.55, gender_education_gap=0.05,
            net_migration_rate=-3.0, diaspora_size=10_000_000, diaspora_as_pct_of_population=0.07,
        ),
        economics=EconomicProfile(
            gdp_total_usd=1_800_000_000_000, gdp_per_capita_usd=12_500,
            gdp_growth_rate=1.0, gdp_growth_trend='unstable',
            gini_coefficient=0.36, poverty_rate=0.12, wealth_top_10_pct=0.45,
            unemployment_rate=0.03, youth_unemployment_rate=0.15, underemployment_rate=0.10,
            public_sector_employment_pct=0.40, informal_economy_pct=0.30, remittance_pct_of_gdp=0.01,
            oil_gas_pct_of_gdp=0.20, oil_gas_pct_of_exports=0.50, oil_gas_pct_of_govt_revenue=0.35,
            under_sanctions=True, sanctions_severity=0.75, trade_openness=0.40,
            inflation_rate=8.0, currency_stability=0.5,
        ),
        information=InformationProfile(
            internet_penetration=0.85, smartphone_penetration=0.75, social_media_users_pct=0.70,
            primary_platforms=['vkontakte', 'telegram', 'odnoklassniki'], vpn_usage_estimate=0.35,
            internet_freedom_score=0.20, social_media_blocked=['facebook', 'instagram', 'twitter'],
            state_surveillance_capacity=0.75, content_filtering_sophistication=0.6,
            state_media_dominance=0.85, independent_media_exists=False, foreign_media_access=0.35,
            journalist_safety_index=0.1, diaspora_media_influence=0.5,
            diaspora_communication_channels=['telegram', 'youtube'],
            word_of_mouth_reliance=0.5, mosque_church_network_strength=0.4, bazaar_market_network_strength=0.3,
        ),
        social=SocialCohesionProfile(
            ethnic_fractionalization=0.25, religious_fractionalization=0.30, linguistic_fractionalization=0.15,
            interpersonal_trust=0.25, institutional_trust=0.35, military_trust=0.50, police_trust=0.30,
            national_identity_strength=0.70, subnational_identity_strength=0.35,
            civil_society_strength=0.1, union_membership_rate=0.20, religious_organization_membership=0.4, ngo_density=0.05,
            years_as_unified_state=33, colonial_history=False, colonial_borders_artificial=False,
            cleavages=[],
        ),
        history=HistoricalMemoryProfile(
            previous_revolutions=[
                HistoricalEvent("Soviet Collapse", 1991, "revolution", "mixed", 100, True, 0.9),
            ],
            years_since_last_revolution=34, last_revolution_outcome="mixed",
            regime_age_years=26, regime_type_changes=1,
            collective_trauma_events=[
                HistoricalEvent("90s Collapse", 1998, "economic", "failure", 100000, True, 0.95),
            ],
            martyr_mythology_strength=0.3, notable_martyrs=['Navalny'], martyr_commemoration_active=False,
            generational_narrative_gap=0.5, founding_generation_alive=True,
            inspiring_revolutions=['Color revolutions'], cautionary_revolutions=['1991 Soviet collapse'],
        ),
        last_updated="2026-01-10", data_quality=0.5,
    )


def create_china_profile() -> CountrySystemicProfile:
    """China - The Great Firewall fortress"""
    return CountrySystemicProfile(
        name="China",
        iso_code="CN",
        demographics=DemographicProfile(
            population_total=1_400_000_000, median_age=39.0,
            age_0_14=0.17, age_15_24=0.11, age_25_54=0.47, age_55_plus=0.25,
            urbanization_rate=0.64, urbanization_trend=0.01, capital_city_concentration=0.015,
            literacy_rate=0.97, university_enrollment_rate=0.55, university_graduates_annual=11_000_000,
            female_labor_participation=0.61, gender_education_gap=0.0,
            net_migration_rate=-0.2, diaspora_size=50_000_000, diaspora_as_pct_of_population=0.036,
        ),
        economics=EconomicProfile(
            gdp_total_usd=18_000_000_000_000, gdp_per_capita_usd=12_500,
            gdp_growth_rate=4.5, gdp_growth_trend='stable',
            gini_coefficient=0.47, poverty_rate=0.03, wealth_top_10_pct=0.40,
            unemployment_rate=0.05, youth_unemployment_rate=0.20, underemployment_rate=0.10,
            public_sector_employment_pct=0.25, informal_economy_pct=0.20, remittance_pct_of_gdp=0.002,
            oil_gas_pct_of_gdp=0.02, oil_gas_pct_of_exports=0.01, oil_gas_pct_of_govt_revenue=0.02,
            under_sanctions=True, sanctions_severity=0.2, trade_openness=0.35,
            inflation_rate=2.0, currency_stability=0.85,
        ),
        information=InformationProfile(
            internet_penetration=0.73, smartphone_penetration=0.70, social_media_users_pct=0.70,
            primary_platforms=['wechat', 'weibo', 'douyin'], vpn_usage_estimate=0.10,
            internet_freedom_score=0.10, social_media_blocked=['google', 'facebook', 'twitter', 'youtube'],
            state_surveillance_capacity=0.95, content_filtering_sophistication=0.95,
            state_media_dominance=0.8, independent_media_exists=False, foreign_media_access=0.2,
            journalist_safety_index=0.15, diaspora_media_influence=0.2,
            diaspora_communication_channels=['limited'],
            word_of_mouth_reliance=0.3, mosque_church_network_strength=0.1, bazaar_market_network_strength=0.3,
        ),
        social=SocialCohesionProfile(
            ethnic_fractionalization=0.15, religious_fractionalization=0.35, linguistic_fractionalization=0.20,
            interpersonal_trust=0.30, institutional_trust=0.55, military_trust=0.70, police_trust=0.50,
            national_identity_strength=0.85, subnational_identity_strength=0.2,
            civil_society_strength=0.1, union_membership_rate=0.15, religious_organization_membership=0.2, ngo_density=0.05,
            years_as_unified_state=75, colonial_history=True, colonial_borders_artificial=False,
            cleavages=[],
        ),
        history=HistoricalMemoryProfile(
            previous_revolutions=[
                HistoricalEvent("Tiananmen Square", 1989, "revolution", "failure", 3000, True, 0.2),
            ],
            years_since_last_revolution=36, last_revolution_outcome="failure",
            regime_age_years=76, regime_type_changes=0,
            collective_trauma_events=[
                HistoricalEvent("Cultural Revolution", 1976, "civil_war", "mixed", 2000000, True, 0.5),
            ],
            martyr_mythology_strength=0.4, notable_martyrs=[], martyr_commemoration_active=False,
            generational_narrative_gap=0.3, founding_generation_alive=False,
            inspiring_revolutions=[], cautionary_revolutions=['Soviet collapse', 'Color revolutions'],
        ),
        last_updated="2026-01-10", data_quality=0.5,
    )


def create_turkey_profile() -> CountrySystemicProfile:
    """Turkey - Erdogan's balancing act"""
    return CountrySystemicProfile(
        name="Turkey",
        iso_code="TR",
        demographics=DemographicProfile(
            population_total=85_000_000, median_age=32.2,
            age_0_14=0.23, age_15_24=0.15, age_25_54=0.43, age_55_plus=0.19,
            urbanization_rate=0.76, urbanization_trend=0.015, capital_city_concentration=0.07,
            literacy_rate=0.96, university_enrollment_rate=0.45, university_graduates_annual=400_000,
            female_labor_participation=0.34, gender_education_gap=-0.01,
            net_migration_rate=1.5, diaspora_size=6_000_000, diaspora_as_pct_of_population=0.07,
        ),
        economics=EconomicProfile(
            gdp_total_usd=900_000_000_000, gdp_per_capita_usd=10_500,
            gdp_growth_rate=3.0, gdp_growth_trend='unstable',
            gini_coefficient=0.42, poverty_rate=0.15, wealth_top_10_pct=0.35,
            unemployment_rate=0.10, youth_unemployment_rate=0.22, underemployment_rate=0.15,
            public_sector_employment_pct=0.15, informal_economy_pct=0.30, remittance_pct_of_gdp=0.01,
            oil_gas_pct_of_gdp=0.01, oil_gas_pct_of_exports=0.05, oil_gas_pct_of_govt_revenue=0.02,
            under_sanctions=False, sanctions_severity=0.0, trade_openness=0.55,
            inflation_rate=50.0, currency_stability=0.3,
        ),
        information=InformationProfile(
            internet_penetration=0.83, smartphone_penetration=0.80, social_media_users_pct=0.75,
            primary_platforms=['twitter', 'instagram', 'youtube', 'tiktok'], vpn_usage_estimate=0.25,
            internet_freedom_score=0.35, social_media_blocked=['wikipedia'],
            state_surveillance_capacity=0.65, content_filtering_sophistication=0.5,
            state_media_dominance=0.70, independent_media_exists=True, foreign_media_access=0.7,
            journalist_safety_index=0.25, diaspora_media_influence=0.5,
            diaspora_communication_channels=['standard platforms'],
            word_of_mouth_reliance=0.5, mosque_church_network_strength=0.7, bazaar_market_network_strength=0.6,
        ),
        social=SocialCohesionProfile(
            ethnic_fractionalization=0.32, religious_fractionalization=0.15, linguistic_fractionalization=0.25,
            interpersonal_trust=0.20, institutional_trust=0.40, military_trust=0.60, police_trust=0.40,
            national_identity_strength=0.75, subnational_identity_strength=0.45,
            civil_society_strength=0.3, union_membership_rate=0.10, religious_organization_membership=0.5, ngo_density=0.15,
            years_as_unified_state=103, colonial_history=False, colonial_borders_artificial=False,
            cleavages=[
                SocialCleavage(CleavageType.ETHNIC, ['Turkish', 'Kurdish'], 'Turkish', 0.75, 0.6, True, True, 0.4),
            ],
        ),
        history=HistoricalMemoryProfile(
            previous_revolutions=[
                HistoricalEvent("Kemalist Revolution", 1923, "revolution", "success", 500000, False, 0.9),
            ],
            years_since_last_revolution=103, last_revolution_outcome="success",
            regime_age_years=23, regime_type_changes=0,
            collective_trauma_events=[
                HistoricalEvent("2016 Coup Attempt", 2016, "coup", "failure", 300, True, 0.85),
            ],
            martyr_mythology_strength=0.5, notable_martyrs=['2016 coup victims'], martyr_commemoration_active=True,
            generational_narrative_gap=0.4, founding_generation_alive=True,
            inspiring_revolutions=[], cautionary_revolutions=['Syria', 'Egypt'],
        ),
        last_updated="2026-01-10", data_quality=0.65,
    )


def create_egypt_profile() -> CountrySystemicProfile:
    """Egypt - Sisi's military consolidation"""
    return CountrySystemicProfile(
        name="Egypt",
        iso_code="EG",
        demographics=DemographicProfile(
            population_total=105_000_000, median_age=24.6,
            age_0_14=0.33, age_15_24=0.17, age_25_54=0.38, age_55_plus=0.12,
            urbanization_rate=0.43, urbanization_trend=0.015, capital_city_concentration=0.20,
            literacy_rate=0.73, university_enrollment_rate=0.35, university_graduates_annual=350_000,
            female_labor_participation=0.22, gender_education_gap=-0.02,
            net_migration_rate=-0.5, diaspora_size=10_000_000, diaspora_as_pct_of_population=0.095,
        ),
        economics=EconomicProfile(
            gdp_total_usd=400_000_000_000, gdp_per_capita_usd=3_800,
            gdp_growth_rate=4.0, gdp_growth_trend='unstable',
            gini_coefficient=0.32, poverty_rate=0.30, wealth_top_10_pct=0.30,
            unemployment_rate=0.08, youth_unemployment_rate=0.25, underemployment_rate=0.25,
            public_sector_employment_pct=0.30, informal_economy_pct=0.40, remittance_pct_of_gdp=0.08,
            oil_gas_pct_of_gdp=0.08, oil_gas_pct_of_exports=0.25, oil_gas_pct_of_govt_revenue=0.15,
            under_sanctions=False, sanctions_severity=0.0, trade_openness=0.35,
            inflation_rate=35.0, currency_stability=0.35,
        ),
        information=InformationProfile(
            internet_penetration=0.72, smartphone_penetration=0.60, social_media_users_pct=0.50,
            primary_platforms=['facebook', 'whatsapp', 'tiktok'], vpn_usage_estimate=0.15,
            internet_freedom_score=0.25, social_media_blocked=[],
            state_surveillance_capacity=0.70, content_filtering_sophistication=0.5,
            state_media_dominance=0.80, independent_media_exists=False, foreign_media_access=0.5,
            journalist_safety_index=0.15, diaspora_media_influence=0.4,
            diaspora_communication_channels=['standard platforms'],
            word_of_mouth_reliance=0.7, mosque_church_network_strength=0.75, bazaar_market_network_strength=0.7,
        ),
        social=SocialCohesionProfile(
            ethnic_fractionalization=0.10, religious_fractionalization=0.15, linguistic_fractionalization=0.05,
            interpersonal_trust=0.25, institutional_trust=0.30, military_trust=0.55, police_trust=0.25,
            national_identity_strength=0.80, subnational_identity_strength=0.2,
            civil_society_strength=0.15, union_membership_rate=0.15, religious_organization_membership=0.6, ngo_density=0.1,
            years_as_unified_state=5000, colonial_history=True, colonial_borders_artificial=False,
            cleavages=[],
        ),
        history=HistoricalMemoryProfile(
            previous_revolutions=[
                HistoricalEvent("2011 Revolution", 2011, "revolution", "mixed", 900, True, 0.9),
                HistoricalEvent("2013 Counter-Revolution", 2013, "coup", "success", 1000, True, 0.85),
            ],
            years_since_last_revolution=13, last_revolution_outcome="mixed",
            regime_age_years=12, regime_type_changes=2,
            collective_trauma_events=[
                HistoricalEvent("Rabaa Massacre", 2013, "massacre", "failure", 1000, True, 0.7),
            ],
            martyr_mythology_strength=0.5, notable_martyrs=['2011 revolutionaries'], martyr_commemoration_active=False,
            generational_narrative_gap=0.5, founding_generation_alive=True,
            inspiring_revolutions=[], cautionary_revolutions=['Syria', 'Libya', 'Yemen'],
        ),
        last_updated="2026-01-10", data_quality=0.6,
    )


def create_north_korea_profile() -> CountrySystemicProfile:
    """North Korea - Total information control"""
    return CountrySystemicProfile(
        name="North Korea",
        iso_code="KP",
        demographics=DemographicProfile(
            population_total=26_000_000, median_age=34.6,
            age_0_14=0.20, age_15_24=0.14, age_25_54=0.44, age_55_plus=0.22,
            urbanization_rate=0.63, urbanization_trend=0.005, capital_city_concentration=0.12,
            literacy_rate=0.99, university_enrollment_rate=0.30, university_graduates_annual=50_000,
            female_labor_participation=0.72, gender_education_gap=0.0,
            net_migration_rate=-0.05, diaspora_size=100_000, diaspora_as_pct_of_population=0.004,
        ),
        economics=EconomicProfile(
            gdp_total_usd=30_000_000_000, gdp_per_capita_usd=1_200,
            gdp_growth_rate=0.0, gdp_growth_trend='stable',
            gini_coefficient=0.30, poverty_rate=0.45, wealth_top_10_pct=0.40,
            unemployment_rate=0.03, youth_unemployment_rate=0.05, underemployment_rate=0.40,
            public_sector_employment_pct=0.95, informal_economy_pct=0.30, remittance_pct_of_gdp=0.05,
            oil_gas_pct_of_gdp=0.0, oil_gas_pct_of_exports=0.0, oil_gas_pct_of_govt_revenue=0.0,
            under_sanctions=True, sanctions_severity=0.95, trade_openness=0.10,
            inflation_rate=5.0, currency_stability=0.3,
        ),
        information=InformationProfile(
            internet_penetration=0.001, smartphone_penetration=0.15, social_media_users_pct=0.0,
            primary_platforms=[], vpn_usage_estimate=0.001,
            internet_freedom_score=0.0, social_media_blocked=['all'],
            state_surveillance_capacity=0.95, content_filtering_sophistication=1.0,
            state_media_dominance=1.0, independent_media_exists=False, foreign_media_access=0.05,
            journalist_safety_index=0.0, diaspora_media_influence=0.1,
            diaspora_communication_channels=['radio', 'usb_smuggling'],
            word_of_mouth_reliance=0.8, mosque_church_network_strength=0.0, bazaar_market_network_strength=0.4,
        ),
        social=SocialCohesionProfile(
            ethnic_fractionalization=0.0, religious_fractionalization=0.0, linguistic_fractionalization=0.0,
            interpersonal_trust=0.10, institutional_trust=0.20, military_trust=0.50, police_trust=0.15,
            national_identity_strength=0.70, subnational_identity_strength=0.1,
            civil_society_strength=0.0, union_membership_rate=0.0, religious_organization_membership=0.0, ngo_density=0.0,
            years_as_unified_state=77, colonial_history=True, colonial_borders_artificial=True,
            cleavages=[],
        ),
        history=HistoricalMemoryProfile(
            previous_revolutions=[], years_since_last_revolution=None, last_revolution_outcome=None,
            regime_age_years=77, regime_type_changes=0,
            collective_trauma_events=[
                HistoricalEvent("Korean War", 1953, "war", "mixed", 1500000, False, 0.95),
                HistoricalEvent("1990s Famine", 1998, "famine", "failure", 2000000, True, 0.6),
            ],
            martyr_mythology_strength=0.6, notable_martyrs=[], martyr_commemoration_active=False,
            generational_narrative_gap=0.3, founding_generation_alive=False,
            inspiring_revolutions=[], cautionary_revolutions=['South Korea prosperity'],
        ),
        last_updated="2026-01-10", data_quality=0.2,
    )


# =============================================================================
# SCENARIO FACTORIES
# =============================================================================

def create_iran_scenario_jan_2026() -> Tuple[RegimeState, RevolutionState, ExternalActors]:
    """Iran - January 2026 live revolution scenario"""
    regime = RegimeState(
        name="Islamic Republic of Iran",
        leader="Khamenei (incapacitated) / IRGC Council",
        regime_type="Theocratic-Military Hybrid",
        legitimacy=0.15,
        economic_resources=0.20,
        security_force_loyalty=0.35,
        elite_cohesion=0.25,
        international_support=0.15,
        information_control=0.40,
        territorial_control=0.50,
        succession_clarity=0.10,
        ideological_commitment=0.30,
        foreign_militia_deployed=True,
        internet_shutdown_active=True,
        martial_law_declared=True,
        mass_arrests_ongoing=True,
    )
    
    revolution = RevolutionState(
        name="Woman Life Freedom Movement",
        active_protesters=5_000_000,
        total_sympathizers=50_000_000,
        organization_level=0.65,
        leadership_identified=False,
        leadership_names=[],
        unified_demands=True,
        primary_demands=["End Islamic Republic", "Democratic transition", "Women's rights"],
        geographic_spread=0.90,
        cross_class_coalition=True,
        cross_ethnic_coalition=True,
        armed_component=False,
        international_support=0.70,
        diaspora_support=0.90,
        martyrs_count=1500,
        fear_threshold_crossed=True,
        momentum=0.95,
    )
    
    external = ExternalActors(
        us_support_level=0.70,
        us_sanctions_active=True,
        us_rhetorical_support=True,
        us_actual_intervention=False,
        regional_power_support=0.60,
        regional_power_opposition=0.20,
        un_involvement=0.30,
        diaspora_funding=0.80,
        foreign_media_coverage=0.90,
        neighboring_country_spillover=0.40,
        great_power_competition_factor=0.50,
    )
    
    return regime, revolution, external


def create_saudi_arabia_scenario() -> Tuple[RegimeState, RevolutionState, ExternalActors]:
    """Saudi Arabia - stable monarchy scenario"""
    regime = RegimeState(
        name="Kingdom of Saudi Arabia",
        leader="Mohammed bin Salman",
        regime_type="Absolute Monarchy",
        legitimacy=0.65,
        economic_resources=0.90,
        security_force_loyalty=0.85,
        elite_cohesion=0.70,
        international_support=0.75,
        information_control=0.70,
        territorial_control=0.95,
        succession_clarity=0.80,
        ideological_commitment=0.50,
    )
    
    revolution = RevolutionState(
        name="N/A",
        active_protesters=0,
        total_sympathizers=500_000,
        organization_level=0.10,
        leadership_identified=False,
        leadership_names=[],
        unified_demands=False,
        primary_demands=[],
        geographic_spread=0.05,
        cross_class_coalition=False,
        cross_ethnic_coalition=False,
        armed_component=False,
        international_support=0.10,
        diaspora_support=0.20,
        martyrs_count=0,
        fear_threshold_crossed=False,
        momentum=0.05,
    )
    
    external = ExternalActors(
        us_support_level=0.80,
        us_sanctions_active=False,
        us_rhetorical_support=True,
        us_actual_intervention=False,
        regional_power_support=0.70,
        regional_power_opposition=0.10,
        un_involvement=0.10,
        diaspora_funding=0.10,
        foreign_media_coverage=0.30,
        neighboring_country_spillover=0.20,
        great_power_competition_factor=0.30,
    )
    
    return regime, revolution, external


def create_russia_scenario() -> Tuple[RegimeState, RevolutionState, ExternalActors]:
    """Russia - post-Ukraine exhaustion scenario"""
    regime = RegimeState(
        name="Russian Federation",
        leader="Vladimir Putin",
        regime_type="Authoritarian Personalist",
        legitimacy=0.45,
        economic_resources=0.50,
        security_force_loyalty=0.70,
        elite_cohesion=0.55,
        international_support=0.30,
        information_control=0.75,
        territorial_control=0.90,
        succession_clarity=0.20,
        ideological_commitment=0.40,
    )
    
    revolution = RevolutionState(
        name="Anti-War Movement",
        active_protesters=50_000,
        total_sympathizers=10_000_000,
        organization_level=0.20,
        leadership_identified=False,
        leadership_names=[],
        unified_demands=False,
        primary_demands=["End Ukraine War", "Democratic reform"],
        geographic_spread=0.30,
        cross_class_coalition=False,
        cross_ethnic_coalition=False,
        armed_component=False,
        international_support=0.50,
        diaspora_support=0.60,
        martyrs_count=10,
        fear_threshold_crossed=False,
        momentum=0.20,
    )
    
    external = ExternalActors(
        us_support_level=0.40,
        us_sanctions_active=True,
        us_rhetorical_support=True,
        us_actual_intervention=False,
        regional_power_support=0.30,
        regional_power_opposition=0.40,
        un_involvement=0.20,
        diaspora_funding=0.40,
        foreign_media_coverage=0.60,
        neighboring_country_spillover=0.30,
        great_power_competition_factor=0.70,
    )
    
    return regime, revolution, external


# =============================================================================
# CURRENT SYSTEM STATE (JANUARY 2026)
# =============================================================================

def create_current_system_state() -> ForcingFunction:
    """Create the current global system state - January 2026"""
    
    system_state = ForcingFunction(
        current_phase=SystemPhase.SOLVE,
        phase_start_date="2023-10-07",
        tempo_ooda_advantage=2.5,
    )
    
    # Proxy Networks
    system_state.proxy_networks = {
        'Hamas': ProxyNetworkStatus('Hamas', 'dissolved', 0.05, 'Iran', '2025-10'),
        'Hezbollah': ProxyNetworkStatus('Hezbollah', 'dissolved', 0.10, 'Iran', '2025-09'),
        'Assad_Syria': ProxyNetworkStatus('Assad Syria', 'dissolved', 0.0, 'Iran/Russia', '2024-12'),
        'Houthis': ProxyNetworkStatus('Houthis', 'isolated', 0.40, 'Iran'),
        'Iraqi_Shia_Militias': ProxyNetworkStatus('Iraqi Shia Militias', 'fragmenting', 0.50, 'Iran'),
        'IRGC_Quds': ProxyNetworkStatus('IRGC Quds Force', 'fragmenting', 0.30, 'Iran'),
    }
    
    # Actor Revelations
    system_state.revealed_actors = {
        'Iran': ActorRevelation('Iran', 'revealed_opposition', 1.0, 'holdout', 0.0, 4),
        'Russia': ActorRevelation('Russia', 'revealed_opposition', 0.9, 'holdout', 0.2, 3),
        'Saudi': ActorRevelation('Saudi Arabia', 'aligned', 0.9, 'new_architecture', 0.5, 0),
        'UAE': ActorRevelation('UAE', 'revealed_aligned', 1.0, 'new_architecture', 0.3, 0),
        'Egypt': ActorRevelation('Egypt', 'aligned', 0.85, 'new_architecture', 0.4, 0),
        'Jordan': ActorRevelation('Jordan', 'aligned', 0.80, 'new_architecture', 0.3, 0),
        'Qatar': ActorRevelation('Qatar', 'hedging', 0.50, None, 0.7, 1),
        'Turkey': ActorRevelation('Turkey', 'hedging', 0.60, None, 0.6, 1),
        'Pakistan': ActorRevelation('Pakistan', 'revealed_aligned', 0.80, 'new_architecture', 0.4, 0),
        'China': ActorRevelation('China', 'hedging', 0.40, 'commerce', 0.8, 2),
    }
    
    # Domestic Flanks
    system_state.domestic_flanks = {
        'US': DomesticFlankStatus('US', True, True, True, True),
        'UK': DomesticFlankStatus('UK', True, True, True, False),
        'Israel': DomesticFlankStatus('Israel', True, True, True, True),
        'France': DomesticFlankStatus('France', True, False, False, False),
        'Germany': DomesticFlankStatus('Germany', True, True, False, False),
    }
    
    # Architecture Nodes
    system_state.architecture_nodes = {
        'UAE': ArchitectureNode('UAE', 'founding', 0.90, 0.85, 0.80, '2020-09'),
        'Bahrain': ArchitectureNode('Bahrain', 'founding', 0.85, 0.80, 0.75, '2020-09'),
        'Morocco': ArchitectureNode('Morocco', 'founding', 0.80, 0.75, 0.70, '2020-12'),
        'Egypt': ArchitectureNode('Egypt', 'active', 0.75, 0.70, 0.65),
        'Jordan': ArchitectureNode('Jordan', 'active', 0.70, 0.65, 0.60),
        'Saudi': ArchitectureNode('Saudi Arabia', 'pending', 0.60, 0.55, 0.50),
        'Kazakhstan': ArchitectureNode('Kazakhstan', 'active', 0.50, 0.45, 0.40, '2025-11'),
        'Somaliland': ArchitectureNode('Somaliland', 'active', 0.30, 0.25, 0.20, '2025-12'),
        'Sudan': ArchitectureNode('Sudan', 'pending', 0.20, 0.15, 0.10),
    }
    
    return system_state


# =============================================================================
# INTEGRATED ASSESSMENT
# =============================================================================

@dataclass
class IntegratedAssessment:
    """Complete three-layer assessment"""
    country_name: str
    timestamp: str
    
    # Layer 1
    structural_instability: float
    regime_structural_strength: float
    cascade_potential: float
    fragmentation_risk: float
    net_structural_instability: float
    
    # Layer 2
    regime_collapse_probability: float
    security_force_defection_risk: float
    preference_cascade_speed: float
    fear_threshold_crossed: bool
    estimated_timeline_days: Tuple[int, int]
    ending_type: str
    violence_forecast: str
    
    # Layer 3
    system_adjusted_collapse: float
    cascade_multiplier: float
    revelation_pressure: float
    architecture_alignment: str
    onus_position: str
    
    # Final
    integrated_collapse_probability: float
    confidence_level: float
    key_drivers: List[str]
    key_stabilizers: List[str]
    watch_variables: List[str]


def create_integrated_assessment(
    systemic_profile: CountrySystemicProfile,
    regime: RegimeState,
    revolution: RevolutionState,
    external: ExternalActors,
    system_state: ForcingFunction
) -> IntegratedAssessment:
    """Create fully integrated three-layer assessment"""
    
    # Layer 1
    structural = systemic_profile.get_full_assessment()
    
    # Layer 2
    collapse_prob = calculate_regime_collapse_probability(regime, revolution, external)
    defection_prob = calculate_defection_probability(regime, revolution)
    cascade_speed = calculate_preference_cascade_speed(regime, revolution)
    timeline = estimate_resolution_timeline(regime, revolution, external)
    violence, violence_intensity = calculate_violence_level(regime, revolution)
    
    # Layer 3
    system_adjusted = apply_system_state_to_collapse(collapse_prob, systemic_profile.name, system_state)
    cascade_mult = system_state.calculate_cascade_multiplier()
    revelation_pressure = system_state.calculate_revelation_pressure(systemic_profile.name)
    onus = system_state.calculate_onus_position()
    
    # Architecture alignment
    architecture_alignment = 'hedging'
    for actor in system_state.revealed_actors.values():
        if actor.name.lower() == systemic_profile.name.lower():
            if actor.chose_side == 'new_architecture':
                architecture_alignment = 'aligned'
            elif actor.chose_side == 'holdout':
                architecture_alignment = 'holdout'
            break
    
    # INTEGRATED SCORE
    integrated_prob = (
        structural['structural_instability'] * 0.25 +
        collapse_prob * 0.50 +
        system_adjusted * 0.25
    )
    
    # Confidence
    layer_spread = abs(structural['structural_instability'] - collapse_prob)
    confidence = systemic_profile.data_quality * (1 - layer_spread * 0.5)
    
    # Key drivers
    key_drivers = []
    if revolution.fear_threshold_crossed:
        key_drivers.append("Fear threshold crossed - population not afraid")
    if defection_prob > 0.5:
        key_drivers.append(f"High defection risk ({defection_prob:.0%})")
    if structural['components']['economic_grievance'] > 0.35:
        key_drivers.append(f"Economic grievance ({structural['components']['economic_grievance']:.0%})")
    if structural['components']['demographic_pressure'] > 0.65:
        key_drivers.append(f"Youth bulge pressure ({structural['components']['demographic_pressure']:.0%})")
    if cascade_speed > 1.5:
        key_drivers.append(f"Fast cascade speed ({cascade_speed:.1f}x)")
    if architecture_alignment == 'holdout':
        key_drivers.append("Revealed as holdout - maximum pressure")
    
    # Key stabilizers
    key_stabilizers = []
    if structural['components']['fear_of_chaos'] > 0.6:
        key_stabilizers.append(f"High fear of chaos ({structural['components']['fear_of_chaos']:.0%})")
    if structural['components']['revolutionary_precedent'] < 0.25:
        key_stabilizers.append(f"No revolutionary precedent ({structural['components']['revolutionary_precedent']:.0%})")
    if regime.security_force_loyalty > 0.7:
        key_stabilizers.append(f"Loyal security forces ({regime.security_force_loyalty:.0%})")
    if regime.economic_resources > 0.7:
        key_stabilizers.append(f"Strong economic resources ({regime.economic_resources:.0%})")
    if architecture_alignment == 'aligned':
        key_stabilizers.append("Aligned with new architecture")
    if not revolution.fear_threshold_crossed:
        key_stabilizers.append("Fear threshold not crossed")
    
    # Watch variables
    watch_variables = [
        "Security force loyalty signals",
        "Elite defection indicators", 
        "External intervention possibilities",
        "Economic resource depletion",
        "Cascade momentum tracking",
    ]
    
    return IntegratedAssessment(
        country_name=systemic_profile.name,
        timestamp=datetime.now().isoformat(),
        structural_instability=structural['structural_instability'],
        regime_structural_strength=structural['regime_structural_strength'],
        cascade_potential=structural['cascade_potential'],
        fragmentation_risk=structural['fragmentation_risk'],
        net_structural_instability=structural['net_instability'],
        regime_collapse_probability=collapse_prob,
        security_force_defection_risk=defection_prob,
        preference_cascade_speed=cascade_speed,
        fear_threshold_crossed=revolution.fear_threshold_crossed,
        estimated_timeline_days=(timeline['days_estimate_low'], timeline['days_estimate_high']),
        ending_type=timeline['ending_type'],
        violence_forecast=violence,
        system_adjusted_collapse=system_adjusted,
        cascade_multiplier=cascade_mult,
        revelation_pressure=revelation_pressure,
        architecture_alignment=architecture_alignment,
        onus_position=onus['burden_holder'],
        integrated_collapse_probability=integrated_prob,
        confidence_level=confidence,
        key_drivers=key_drivers,
        key_stabilizers=key_stabilizers,
        watch_variables=watch_variables,
    )


# =============================================================================
# DISPLAY FUNCTIONS
# =============================================================================

def print_header():
    """Print the game header"""
    print("""
╔══════════════════════════════════════════════════════════════════════════════╗
║                         C O N F L I C T   L A B                              ║
║                    Integrated Geopolitical Analysis Engine                   ║
║                              Version 2.0                                     ║
╚══════════════════════════════════════════════════════════════════════════════╝
    """)


def print_system_state(system_state: ForcingFunction):
    """Print current system state"""
    print("\n" + "="*70)
    print("SYSTEM STATE: SOLVE ET COAGULA")
    print("="*70)
    print(f"Current Phase: {system_state.current_phase.name}")
    print(f"Phase Start: {system_state.phase_start_date}")
    
    dissolved = sum(1 for p in system_state.proxy_networks.values() if p.status == 'dissolved')
    remaining = len(system_state.proxy_networks) - dissolved
    
    print(f"\n--- DISSOLUTION STATUS ---")
    print(f"Proxies Dissolved: {dissolved}")
    print(f"Proxies Remaining: {remaining}")
    print(f"Cascade Multiplier: {system_state.calculate_cascade_multiplier():.3f}x")
    
    print(f"\n--- REVELATION STATUS ---")
    print(f"Ambiguity Remaining: {system_state.calculate_ambiguity_remaining():.1%}")
    revealed = sum(1 for a in system_state.revealed_actors.values() if a.revelation_complete > 0.7)
    hedging = sum(1 for a in system_state.revealed_actors.values() if a.position == 'hedging')
    print(f"Actors Revealed: {revealed}")
    print(f"Actors Still Hedging: {hedging}")
    
    onus = system_state.calculate_onus_position()
    print(f"\n--- ONUS POSITION ---")
    print(f"Burden Holder: {onus['burden_holder']}")
    
    print(f"\n--- ARCHITECTURE MOMENTUM ---")
    print(f"Momentum: {system_state.calculate_architecture_momentum():.1%}")
    secured = sum(1 for d in system_state.domestic_flanks.values() 
                  if d.protest_networks_mapped and d.legal_framework_established)
    print(f"Domestic Flanks Secured: {secured}")
    
    print(f"\n--- TEMPO ---")
    print(f"OODA Loop Advantage: {system_state.tempo_ooda_advantage} cycles ahead")


def print_structural_comparison(profiles: List[CountrySystemicProfile]):
    """Print comparative structural analysis"""
    print("\n" + "="*80)
    print("STRUCTURAL COMPARISON (Forest Level)")
    print("="*80)
    print(f"\n{'Country':<15} {'Instab':<10} {'Regime':<10} {'NET':<10} {'Cascade':<10} {'Fragment':<10}")
    print("-"*80)
    
    for p in profiles:
        a = p.get_full_assessment()
        print(f"{a['name']:<15} {a['structural_instability']:>8.1%} {a['regime_structural_strength']:>8.1%} "
              f"{a['net_instability']:>+8.1%} {a['cascade_potential']:>8.1%} {a['fragmentation_risk']:>8.1%}")


def print_assessment(assessment: IntegratedAssessment):
    """Print full integrated assessment"""
    print("\n" + "="*70)
    print(f"INTEGRATED ASSESSMENT: {assessment.country_name}")
    print(f"Timestamp: {assessment.timestamp}")
    print("="*70)
    
    print("\n┌" + "─"*68 + "┐")
    print(f"│ FINAL VERDICT: {assessment.integrated_collapse_probability:>6.1%} collapse probability"
          + " "*(36) + "│")
    print(f"│ Confidence: {assessment.confidence_level:.0%}" + " "*54 + "│")
    print("└" + "─"*68 + "┘")
    
    print(f"\n📊 LAYER 1: STRUCTURAL")
    print(f"   Net Instability:     {assessment.net_structural_instability:>+7.1%}")
    print(f"   Cascade Potential:   {assessment.cascade_potential:>7.1%}")
    print(f"   Fragmentation Risk:  {assessment.fragmentation_risk:>7.1%}")
    
    print(f"\n⚔️  LAYER 2: DYNAMIC")
    print(f"   Base Collapse Prob:  {assessment.regime_collapse_probability:>7.1%}")
    print(f"   Defection Risk:      {assessment.security_force_defection_risk:>7.1%}")
    print(f"   Cascade Speed:       {assessment.preference_cascade_speed:>7.2f}x")
    print(f"   Fear Threshold:      {'CROSSED ✓' if assessment.fear_threshold_crossed else 'Not crossed'}")
    print(f"   Timeline:            {assessment.estimated_timeline_days[0]}-{assessment.estimated_timeline_days[1]} days")
    print(f"   Likely Ending:       {assessment.ending_type}")
    
    print(f"\n🌍 LAYER 3: SYSTEM STATE")
    print(f"   Cascade Multiplier:  {assessment.cascade_multiplier:>7.2f}x")
    print(f"   Revelation Pressure: {assessment.revelation_pressure:>7.1%}")
    print(f"   Architecture:        {assessment.architecture_alignment}")
    print(f"   Onus Position:       {assessment.onus_position}")
    
    if assessment.key_drivers:
        print(f"\n🔑 KEY DRIVERS:")
        for d in assessment.key_drivers[:5]:
            print(f"   • {d}")
    
    if assessment.key_stabilizers:
        print(f"\n🛡️ KEY STABILIZERS:")
        for s in assessment.key_stabilizers[:5]:
            print(f"   • {s}")
    
    print("\n" + "="*70)


# =============================================================================
# INTERACTIVE GAME INTERFACE
# =============================================================================

def run_interactive():
    """Run the interactive game interface"""
    print_header()
    
    # Load all profiles
    profiles = {
        'iran': create_iran_profile(),
        'saudi': create_saudi_profile(),
        'russia': create_russia_profile(),
        'china': create_china_profile(),
        'turkey': create_turkey_profile(),
        'egypt': create_egypt_profile(),
        'north_korea': create_north_korea_profile(),
    }
    
    # Load system state
    system_state = create_current_system_state()
    
    # Scenario factories
    scenarios = {
        'iran': create_iran_scenario_jan_2026,
        'saudi': create_saudi_arabia_scenario,
        'russia': create_russia_scenario,
    }
    
    while True:
        print("\n" + "─"*50)
        print("MAIN MENU")
        print("─"*50)
        print("1. View System State (Solve et Coagula)")
        print("2. View Structural Comparison (All Countries)")
        print("3. Run Full Assessment (Iran)")
        print("4. Run Full Assessment (Saudi Arabia)")
        print("5. Run Full Assessment (Russia)")
        print("6. View Country Profile")
        print("7. Compare Two Countries")
        print("8. Run All Assessments")
        print("9. Export Assessment to JSON")
        print("0. Exit")
        print("─"*50)
        
        choice = input("\nSelect option: ").strip()
        
        if choice == '1':
            print_system_state(system_state)
            
        elif choice == '2':
            print_structural_comparison(list(profiles.values()))
            
        elif choice in ['3', '4', '5']:
            country_map = {'3': 'iran', '4': 'saudi', '5': 'russia'}
            country = country_map[choice]
            profile = profiles[country]
            regime, revolution, external = scenarios[country]()
            assessment = create_integrated_assessment(profile, regime, revolution, external, system_state)
            print_assessment(assessment)
            
        elif choice == '6':
            print("\nAvailable countries:", ', '.join(profiles.keys()))
            country = input("Enter country name: ").strip().lower()
            if country in profiles:
                profile = profiles[country]
                a = profile.get_full_assessment()
                print(f"\n{profile.name} ({profile.iso_code})")
                print(f"Data Quality: {profile.data_quality:.0%}")
                print(f"\nStructural Instability: {a['structural_instability']:.1%}")
                print(f"Regime Strength: {a['regime_structural_strength']:.1%}")
                print(f"NET: {a['net_instability']:+.1%}")
                print(f"Cascade Potential: {a['cascade_potential']:.1%}")
                print(f"\nComponents:")
                for k, v in a['components'].items():
                    print(f"  {k}: {v:.1%}")
            else:
                print("Country not found.")
                
        elif choice == '7':
            print("\nAvailable countries:", ', '.join(profiles.keys()))
            c1 = input("First country: ").strip().lower()
            c2 = input("Second country: ").strip().lower()
            if c1 in profiles and c2 in profiles:
                print_structural_comparison([profiles[c1], profiles[c2]])
            else:
                print("One or both countries not found.")
                
        elif choice == '8':
            print("\n" + "="*70)
            print("RUNNING ALL ASSESSMENTS")
            print("="*70)
            
            for country, scenario_fn in scenarios.items():
                profile = profiles[country]
                regime, revolution, external = scenario_fn()
                assessment = create_integrated_assessment(profile, regime, revolution, external, system_state)
                print_assessment(assessment)
                
        elif choice == '9':
            print("\nAvailable countries with scenarios:", ', '.join(scenarios.keys()))
            country = input("Enter country name: ").strip().lower()
            if country in scenarios:
                profile = profiles[country]
                regime, revolution, external = scenarios[country]()
                assessment = create_integrated_assessment(profile, regime, revolution, external, system_state)
                filename = f"{country}_assessment_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
                
                data = {
                    'country': assessment.country_name,
                    'timestamp': assessment.timestamp,
                    'integrated_probability': assessment.integrated_collapse_probability,
                    'confidence': assessment.confidence_level,
                    'layers': {
                        'structural': {
                            'instability': assessment.structural_instability,
                            'regime_strength': assessment.regime_structural_strength,
                            'net': assessment.net_structural_instability,
                        },
                        'dynamic': {
                            'collapse_prob': assessment.regime_collapse_probability,
                            'defection_risk': assessment.security_force_defection_risk,
                            'cascade_speed': assessment.preference_cascade_speed,
                        },
                        'system_state': {
                            'cascade_multiplier': assessment.cascade_multiplier,
                            'revelation_pressure': assessment.revelation_pressure,
                            'alignment': assessment.architecture_alignment,
                        },
                    },
                    'key_drivers': assessment.key_drivers,
                    'key_stabilizers': assessment.key_stabilizers,
                }
                
                with open(filename, 'w') as f:
                    json.dump(data, f, indent=2)
                print(f"Assessment exported to: {filename}")
            else:
                print("Country not found or no scenario available.")
                
        elif choice == '0':
            print("\nExiting Conflict Lab. Stay vigilant. 🌲")
            break
        else:
            print("Invalid option.")


# =============================================================================
# MAIN
# =============================================================================

if __name__ == "__main__":
    run_interactive()

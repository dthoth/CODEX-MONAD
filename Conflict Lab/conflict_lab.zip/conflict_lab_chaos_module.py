import numpy as np
import panel as pn
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from dataclasses import dataclass
from enum import Enum

pn.extension('plotly')

# --- Static data: countries ---

COUNTRIES = {
    "USA": {
        "GDP": 30.6, "ActiveManpower": 1_400_000,
        "IndustrialCapacity": 95, "EnergySecurity": 92,
        "FoodSecurity": 98, "StrategicResources": 92,
        "GroundPower": 92, "AirPower": 100, "NavalPower": 100, "MissilePower": 98,
        "CyberPower": 100, "NuclearDeterrent": 100,
        "PoliticalCohesion": 85, "WarTolerance": 70,
        "EliteStability": 90, "InternationalSupportBase": 98,
    },
    "China": {
        "GDP": 19.2, "ActiveManpower": 2_035_000,
        "IndustrialCapacity": 100, "EnergySecurity": 82,
        "FoodSecurity": 88, "StrategicResources": 95,
        "GroundPower": 95, "AirPower": 88, "NavalPower": 92, "MissilePower": 95,
        "CyberPower": 95, "NuclearDeterrent": 85,
        "PoliticalCohesion": 95, "WarTolerance": 90,
        "EliteStability": 95, "InternationalSupportBase": 65,
    },
    "Russia": {
        "GDP": 2.8, "ActiveManpower": 1_320_000,
        "IndustrialCapacity": 65, "EnergySecurity": 98,
        "FoodSecurity": 85, "StrategicResources": 88,
        "GroundPower": 94, "AirPower": 82, "NavalPower": 78, "MissilePower": 99,
        "CyberPower": 92, "NuclearDeterrent": 100,
        "PoliticalCohesion": 82, "WarTolerance": 92,
        "EliteStability": 78, "InternationalSupportBase": 45,
    },
    "India": {
        "GDP": 4.2, "ActiveManpower": 1_455_000,
        "IndustrialCapacity": 75, "EnergySecurity": 70,
        "FoodSecurity": 85, "StrategicResources": 70,
        "GroundPower": 97, "AirPower": 78, "NavalPower": 68, "MissilePower": 88,
        "CyberPower": 72, "NuclearDeterrent": 65,
        "PoliticalCohesion": 85, "WarTolerance": 88,
        "EliteStability": 80, "InternationalSupportBase": 75,
    },
    "Japan": {
        "GDP": 4.2, "ActiveManpower": 247_000,
        "IndustrialCapacity": 95, "EnergySecurity": 60,
        "FoodSecurity": 90, "StrategicResources": 92,
        "GroundPower": 78, "AirPower": 96, "NavalPower": 94, "MissilePower": 75,
        "CyberPower": 85, "NuclearDeterrent": 0,
        "PoliticalCohesion": 92, "WarTolerance": 65,
        "EliteStability": 95, "InternationalSupportBase": 95,
    },
    "South Korea": {
        "GDP": 1.8, "ActiveManpower": 500_000,
        "IndustrialCapacity": 92, "EnergySecurity": 75,
        "FoodSecurity": 90, "StrategicResources": 85,
        "GroundPower": 98, "AirPower": 90, "NavalPower": 88, "MissilePower": 82,
        "CyberPower": 82, "NuclearDeterrent": 0,
        "PoliticalCohesion": 88, "WarTolerance": 80,
        "EliteStability": 90, "InternationalSupportBase": 92,
    },
    "France": {
        "GDP": 3.1, "ActiveManpower": 203_000,
        "IndustrialCapacity": 85, "EnergySecurity": 95,
        "FoodSecurity": 95, "StrategicResources": 85,
        "GroundPower": 82, "AirPower": 95, "NavalPower": 92, "MissilePower": 95,
        "CyberPower": 90, "NuclearDeterrent": 90,
        "PoliticalCohesion": 85, "WarTolerance": 70,
        "EliteStability": 88, "InternationalSupportBase": 94,
    },
    "UK": {
        "GDP": 3.5, "ActiveManpower": 150_000,
        "IndustrialCapacity": 88, "EnergySecurity": 85,
        "FoodSecurity": 95, "StrategicResources": 88,
        "GroundPower": 78, "AirPower": 94, "NavalPower": 92, "MissilePower": 85,
        "CyberPower": 95, "NuclearDeterrent": 85,
        "PoliticalCohesion": 82, "WarTolerance": 68,
        "EliteStability": 90, "InternationalSupportBase": 96,
    },
}

ZONES = {
    "Open Plains":     {"Ground": 0.45, "Air": 0.35, "Naval": 0.05, "Missile": 0.15},
    "Baltic Sea":      {"Ground": 0.20, "Air": 0.35, "Naval": 0.35, "Missile": 0.10},
    "South China Sea": {"Ground": 0.05, "Air": 0.35, "Naval": 0.50, "Missile": 0.10},
    "Persian Gulf":    {"Ground": 0.10, "Air": 0.40, "Naval": 0.40, "Missile": 0.10},
    "Domestic":        {"Ground": 0.70, "Air": 0.20, "Naval": 0.00, "Missile": 0.10},
    "Arctic":          {"Ground": 0.30, "Air": 0.40, "Naval": 0.20, "Missile": 0.10},
}

AIR_SUP_MULTS = {
    "Enemy Air Sup": 0.3,
    "Contested":     0.7,
    "Local Sup":     1.0,
    "Theater Sup":   1.6,
}

# --- Chaos module support types ---

class CommanderArchetype(Enum):
    thomas_rock = "thomas_rock"   # cautious, methodical
    napoleonic = "napoleonic"     # aggressive, risk-seeking
    cautious_bureaucrat = "cautious_bureaucrat"
    gambler = "gambler"


@dataclass
class HumanFactors:
    leader_ego: float = 0.5        # 0–1
    groupthink: float = 0.5        # 0–1
    victory_disease: float = 0.0   # 0–1
    micro_management: float = 0.5  # 0–1
    risk_aversion: float = 0.5     # 0–1
    fog_of_war_noise: float = 0.5  # 0–1
    black_swan_bias: float = 0.3   # 0–1


@dataclass
class PoliticalConstraints:
    public_war_support: float = 0.5  # 0–1


def _commander_volatility(cmd: CommanderArchetype) -> float:
    if cmd == CommanderArchetype.thomas_rock:
        return 0.15
    if cmd == CommanderArchetype.napoleonic:
        return 0.35
    if cmd == CommanderArchetype.cautious_bureaucrat:
        return 0.1
    if cmd == CommanderArchetype.gambler:
        return 0.45
    return 0.25


def _human_volatility(hf: HumanFactors) -> float:
    vals = [
        hf.leader_ego,
        hf.groupthink,
        hf.victory_disease,
        hf.micro_management,
        hf.risk_aversion,
        hf.fog_of_war_noise,
        hf.black_swan_bias,
    ]
    return float(np.mean(vals))


def apply_commander_modifiers(power: float, commander: CommanderArchetype, situation: dict) -> float:
    """Deterministic multiplier based on archetype and posture."""
    mult = 1.0
    attacking = situation.get("attacking", False)
    defending = situation.get("defender", False)

    if commander == CommanderArchetype.napoleonic:
        if attacking:
            mult *= 1.15
        if defending:
            mult *= 0.9
    elif commander == CommanderArchetype.thomas_rock:
        if attacking:
            mult *= 0.95
        if defending:
            mult *= 1.05
    elif commander == CommanderArchetype.cautious_bureaucrat:
        mult *= 0.95
    elif commander == CommanderArchetype.gambler:
        mult *= 1.1

    return power * mult


def calculate_war_outcome_with_chaos(
    base_results: dict,
    commander_a: CommanderArchetype,
    commander_b: CommanderArchetype,
    human_factors_a: HumanFactors,
    human_factors_b: HumanFactors,
    political_a: PoliticalConstraints,
    political_b: PoliticalConstraints,
    enable_black_swans: bool = True,
) -> dict:
    """Overlay stochastic chaos on top of base_results without re-running the sim."""
    ratio = base_results.get("power_ratio_a_b", 1.0)
    base_winner = base_results.get("winner", "Stalemate")
    base_duration = base_results.get("duration_days", 0.0)
    base_nuke_risk = base_results.get("nuke_risk", 0.0)

    if base_winner.startswith("A"):
        base_side = "A"
    elif base_winner.startswith("B"):
        base_side = "B"
    else:
        base_side = "Stalemate"

    vol_cmd = (_commander_volatility(commander_a) + _commander_volatility(commander_b)) / 2.0
    vol_hf = (_human_volatility(human_factors_a) + _human_volatility(human_factors_b)) / 2.0
    base_vol = 0.1 + 0.3 * vol_cmd + 0.3 * vol_hf

    # Chaos shock on log ratio
    log_r = float(np.log(max(ratio, 1e-3)))
    shock = float(np.random.normal(0.0, base_vol))
    black_swan_triggered = False

    if enable_black_swans:
        # Probability weighted by combined black_swan_bias
        bs_bias = (human_factors_a.black_swan_bias + human_factors_b.black_swan_bias) / 2.0
        if np.random.rand() < 0.1 + 0.4 * bs_bias:
            shock += float(np.random.normal(0.0, 0.7))
            black_swan_triggered = True

    log_r_chaos = log_r + shock
    ratio_chaos = float(np.exp(log_r_chaos))

    # Determine chaos winner side
    if ratio_chaos > 1.2:
        chaos_side = "A"
    elif ratio_chaos < 1 / 1.2:
        chaos_side = "B"
    else:
        chaos_side = "Stalemate"

    chaos_reversal = (
        chaos_side != base_side and
        chaos_side != "Stalemate" and
        base_side != "Stalemate"
    )

    # Simple duration and nuke risk adjustments
    duration_factor = float(np.clip(1.0 + np.random.normal(0.0, base_vol * 0.3), 0.5, 1.5))
    chaos_duration = base_duration * duration_factor

    nuke_delta = 0.0
    if black_swan_triggered:
        # public support erosion + desperation can bump nuke risk a bit
        desperation = max(base_results.get("frac_a", 0.0), base_results.get("frac_b", 0.0))
        if desperation > 0.3:
            nuke_delta = 10.0

    chaos_nuke_risk = float(np.clip(base_nuke_risk + nuke_delta, 0, 100))

    # Public support: increase regime risk if chaos stretches duration
    extra_regime_a = 0.0
    extra_regime_b = 0.0
    if chaos_duration > base_duration and base_duration > 0:
        stretch = (chaos_duration / base_duration) - 1.0
        extra_regime_a = 10.0 * stretch * (1 - political_a.public_war_support)
        extra_regime_b = 10.0 * stretch * (1 - political_b.public_war_support)

    return {
        "chaos_enabled": True,
        "base_winner": base_winner,
        "base_winner_side": base_side,
        "chaos_winner_side": chaos_side,
        "chaos_reversal": chaos_reversal,
        "ratio_before": ratio,
        "ratio_after": ratio_chaos,
        "chaos_log_shock": shock,
        "black_swan_triggered": black_swan_triggered,
        "chaos_duration_days": chaos_duration,
        "chaos_nuke_risk": chaos_nuke_risk,
        "chaos_extra_regime_a": extra_regime_a,
        "chaos_extra_regime_b": extra_regime_b,
    }


def generate_chaos_report(chaos: dict, commander_a_label: str, commander_b_label: str) -> str:
    if not chaos.get("chaos_enabled", False):
        return ""

    lines = []
    lines.append("\n### Chaos Module Report")
    lines.append(f"- Commander A: **{commander_a_label}**, Commander B: **{commander_b_label}**")
    lines.append(f"- Power ratio A:B shifted from **{chaos['ratio_before']:.2f}:1** to **{chaos['ratio_after']:.2f}:1**")
    if chaos["chaos_reversal"]:
        lines.append("- **Outcome reversal**: Chaos suggests the opposite side could plausibly prevail.")
    else:
        lines.append("- No full reversal, but outcome margins shifted under chaos.")
    if chaos["black_swan_triggered"]:
        lines.append("- **Black Swan Event** triggered: rare extreme shock applied.")
    lines.append(f"- Chaos-adjusted nuclear risk: **{chaos['chaos_nuke_risk']:.1f}%**")
    return "\n".join(lines)


# --- Conventional war model ---

def compute_effective_power(country_data, sliders, zone_weights):
    base = (
        zone_weights["Ground"]  * country_data["GroundPower"] +
        zone_weights["Air"]     * country_data["AirPower"] +
        zone_weights["Naval"]   * country_data["NavalPower"] +
        zone_weights["Missile"] * country_data["MissilePower"]
    )

    mob  = 0.3 + 1.2 * (sliders["MobilizationLevel"] / 100)
    qual = 0.6 + 0.9 * (sliders["ForceQuality"] / 100)
    isr  = 0.7 + 0.8 * (sliders["ISRAdvantage"] / 100)
    logi = 0.5 + 1.0 * (sliders["LogisticsPreparedness"] / 100)
    alli = 0.8 + 0.6 * (sliders["AllianceSupport"] / 100)
    roe  = 0.5 + 1.0 * (sliders["ROE_Flexibility"] / 100)

    air_mult = AIR_SUP_MULTS[sliders["AirSuperiority"]]

    mult = mob * qual * isr * logi * alli * roe * air_mult
    return base * mult


def sim_conventional_war(side_a_countries, side_b_countries, sliders_a, sliders_b, zone_name):
    zone_w = ZONES[zone_name]

    # Projection penalty: low alliance support in non-domestic theater
    proj_mult_a = 1.0
    proj_mult_b = 1.0
    if zone_name != "Domestic" and sliders_a["AllianceSupport"] < 40:
        proj_mult_a *= 0.85
    if zone_name != "Domestic" and sliders_b["AllianceSupport"] < 40:
        proj_mult_b *= 0.85

    power_a = sum(compute_effective_power(COUNTRIES[c], sliders_a, zone_w) for c in side_a_countries) * proj_mult_a
    power_b = sum(compute_effective_power(COUNTRIES[c], sliders_b, zone_w) for c in side_b_countries) * proj_mult_b
    ratio   = power_a / power_b if power_b > 0 else 10

    # Initial committed strength (thousands)
    init_a = max(
        1,
        sum(COUNTRIES[c]["ActiveManpower"] * sliders_a["MobilizationLevel"] / 100 / 1000 for c in side_a_countries)
    )
    init_b = max(
        1,
        sum(COUNTRIES[c]["ActiveManpower"] * sliders_b["MobilizationLevel"] / 100 / 1000 for c in side_b_countries)
    )

    dt = 1           # days
    max_days = 2000
    kill_coeff = 0.035   # tuned up (shorter, sharper wars)

    str_a, str_b = init_a, init_b
    cas_a, cas_b = 0.0, 0.0
    times, str_as, str_bs = [0], [init_a], [init_b]
    t = 0
    winner = None
    surrendered_side = None

    while t < max_days and str_a > max(1, init_a * 0.01) and str_b > max(1, init_b * 0.01):
        eff_power_a = power_a * (str_a / init_a)
        eff_power_b = power_b * (str_b / init_b)

        losses_a = kill_coeff * eff_power_b * dt
        losses_b = kill_coeff * eff_power_a * dt

        str_a = max(0, str_a - losses_a)
        str_b = max(0, str_b - losses_b)
        cas_a += losses_a
        cas_b += losses_b

        t += dt
        times.append(t)
        str_as.append(str_a)
        str_bs.append(str_b)

        # Surrender checks
        frac_a = cas_a / init_a
        thresh_a = min(0.95, (sliders_a["WarTolerance"] / 100) * (sliders_a["PoliticalWill"] / 100))
        if frac_a > thresh_a:
            winner = "B (A surrenders)"
            surrendered_side = "A"
            break

        frac_b = cas_b / init_b
        thresh_b = min(0.95, (sliders_b["WarTolerance"] / 100) * (sliders_b["PoliticalWill"] / 100))
        if frac_b > thresh_b:
            winner = "A (B surrenders)"
            surrendered_side = "B"
            break

    if winner is None:
        if str_a > str_b * 1.1:
            winner = "A"
        elif str_b > str_a * 1.1:
            winner = "B"
        else:
            winner = "Stalemate"

    duration_days = t
    frac_a = cas_a / init_a if init_a > 0 else 0
    frac_b = cas_b / init_b if init_b > 0 else 0

    econ_a = min(100, 4 + duration_days / 90 + 15 * frac_a)
    econ_b = min(100, 4 + duration_days / 90 + 15 * frac_b)
    regime_a = min(100, 15 * frac_a * (120 - sliders_a["PoliticalWill"]) / 100)
    regime_b = min(100, 15 * frac_b * (120 - sliders_b["PoliticalWill"]) / 100)

    nuke_a = any(COUNTRIES[c]["NuclearDeterrent"] > 30 for c in side_a_countries)
    nuke_b = any(COUNTRIES[c]["NuclearDeterrent"] > 30 for c in side_b_countries)
    nukes_present = nuke_a or nuke_b
    nuke_risk = 0
    if nukes_present:
        desperation = max(frac_a, frac_b) > 0.3 and duration_days > 180
        imbalance   = min(ratio, 1 / ratio) < 0.6
        nuke_risk = 5 + 25 * int(desperation) + 30 * int(imbalance)

    return {
        "times": times,
        "strengths_a": str_as,
        "strengths_b": str_bs,
        "winner": winner,
        "surrendered_side": surrendered_side,
        "duration_days": duration_days,
        "casualties_a": round(cas_a * 1000),
        "casualties_b": round(cas_b * 1000),
        "initial_a": init_a * 1000,
        "initial_b": init_b * 1000,
        "frac_a": frac_a,
        "frac_b": frac_b,
        "econ_a_pct": round(econ_a, 1),
        "econ_b_pct": round(econ_b, 1),
        "regime_a": round(regime_a, 1),
        "regime_b": round(regime_b, 1),
        "nuke_risk": round(nuke_risk, 1),
        "power_ratio_a_b": round(ratio, 2),
        "power_a": power_a,
        "power_b": power_b,
    }


# --- Economic warfare model ---

def sim_economic_war(side_a_countries, side_b_countries, sliders_s, sliders_t):
    # A = sanctioners, B = target
    coalition_gdp = sum(COUNTRIES[c]["GDP"] for c in side_a_countries) or 0.0
    target_gdp = sum(COUNTRIES[c]["GDP"] for c in side_b_countries) or 0.0
    total_gdp = coalition_gdp + target_gdp if (coalition_gdp + target_gdp) > 0 else 1.0

    base_leverage = coalition_gdp / total_gdp
    lev_slider = sliders_s["CoalitionLeverage"] / 100.0
    coalition_leverage = float(np.clip(base_leverage * (0.5 + 0.5 * lev_slider), 0, 1))

    # Structural resilience from energy/food/resources
    if side_b_countries:
        struct_vals = []
        for c in side_b_countries:
            cd = COUNTRIES[c]
            struct_vals.append((cd["EnergySecurity"] + cd["FoodSecurity"] + cd["StrategicResources"]) / 3)
        struct_res = sum(struct_vals) / len(struct_vals) / 100.0
    else:
        struct_res = 0.5

    slider_res = sliders_t["Resilience"] / 100.0
    alt_markets = sliders_t["AltMarkets"] / 100.0

    resilience = float(np.clip(0.4 * struct_res + 0.4 * slider_res + 0.2 * alt_markets, 0, 1))

    enforcement = sliders_s["EnforcementIntensity"] / 100.0
    fin_pen = sliders_s["FinancialPenetration"] / 100.0
    time_years = sliders_s["TimeHorizonMonths"] / 12.0

    damage_target = 15 * time_years * coalition_leverage * enforcement * fin_pen * (1 - resilience)
    damage_target = float(np.clip(damage_target, 0, 60))

    blowback = damage_target * 0.2 * (1 - coalition_leverage)
    blowback = float(np.clip(blowback, 0, 15))

    regime_stress = float(np.clip(damage_target * (1 + (1 - resilience)), 0, 100))
    success_prob = float(np.clip(damage_target * (coalition_leverage + enforcement) / 2, 0, 100))

    return {
        "coalition_gdp": coalition_gdp,
        "target_gdp": target_gdp,
        "coalition_leverage": round(coalition_leverage, 2),
        "target_damage_pct": round(damage_target, 1),
        "coalition_damage_pct": round(blowback, 1),
        "target_regime_stress": round(regime_stress, 1),
        "sanctions_success_prob": round(success_prob, 1),
        "resilience": round(resilience, 2),
        "time_years": round(time_years, 1),
    }


# --- Helpers for UI defaults ---

def get_side_political_defaults(country_names):
    if not country_names:
        return {"WarTolerance": 75, "PoliticalWill": 80}

    war_vals = []
    will_vals = []
    for name in country_names:
        c = COUNTRIES[name]
        war_vals.append(c.get("WarTolerance", 75))
        avg_will = (c.get("PoliticalCohesion", 80) + c.get("EliteStability", 80)) / 2
        will_vals.append(avg_will)

    return {
        "WarTolerance": int(sum(war_vals) / len(war_vals)),
        "PoliticalWill": int(sum(will_vals) / len(will_vals)),
    }


def make_side_sliders(prefix, defaults, air_default="Contested"):
    sliders = {
        k: pn.widgets.IntSlider(
            name=f"{prefix}: {k.replace('_', ' ').title()}",
            start=0, end=100, value=v
        )
        for k, v in defaults.items()
    }
    sliders["AirSuperiority"] = pn.widgets.Select(
        name=f"{prefix}: Air Superiority",
        options=list(AIR_SUP_MULTS.keys()),
        value=air_default,
    )
    return sliders


# --- UI: Conventional war tab ---

side_a_conv = pn.widgets.MultiChoice(
    name="Side A Countries",
    options=list(COUNTRIES.keys()),
    value=["USA"],
)
side_b_conv = pn.widgets.MultiChoice(
    name="Side B Countries",
    options=list(COUNTRIES.keys()),
    value=["China"],
)
zone_conv = pn.widgets.Select(
    name="Conflict Zone",
    options=list(ZONES.keys()),
    value="South China Sea",
)

default_sliders_conv = {
    "MobilizationLevel": 70,
    "ForceQuality": 80,
    "ISRAdvantage": 70,
    "LogisticsPreparedness": 75,
    "AllianceSupport": 50,
    "ROE_Flexibility": 60,
    "WarTolerance": 75,
    "PoliticalWill": 80,
}

sliders_a_conv = make_side_sliders("A", default_sliders_conv)
sliders_b_conv = make_side_sliders("B", default_sliders_conv)

def _update_side_a_politics(event=None):
    defaults = get_side_political_defaults(side_a_conv.value)
    sliders_a_conv["WarTolerance"].value = defaults["WarTolerance"]
    sliders_a_conv["PoliticalWill"].value = defaults["PoliticalWill"]

def _update_side_b_politics(event=None):
    defaults = get_side_political_defaults(side_b_conv.value)
    sliders_b_conv["WarTolerance"].value = defaults["WarTolerance"]
    sliders_b_conv["PoliticalWill"].value = defaults["PoliticalWill"]

side_a_conv.param.watch(lambda e: _update_side_a_politics(), 'value')
side_b_conv.param.watch(lambda e: _update_side_b_politics(), 'value')

_update_side_a_politics()
_update_side_b_politics()

# Chaos controls
chaos_mode = pn.widgets.Checkbox(
    name="Enable Chaos Module (Human Irrationality + Black Swans)", value=False
)
commander_a = pn.widgets.Select(
    name="Side A Commander Archetype",
    options=[e.value for e in CommanderArchetype],
    value="thomas_rock",
)
commander_b = pn.widgets.Select(
    name="Side B Commander Archetype",
    options=[e.value for e in CommanderArchetype],
    value="napoleonic",
)

# Human factor sliders (0-100, mapped to 0-1)
def make_human_factor_sliders(prefix):
    return {
        "leader_ego": pn.widgets.IntSlider(name=f"{prefix}: Leader Ego", start=0, end=100, value=50),
        "groupthink": pn.widgets.IntSlider(name=f"{prefix}: Groupthink", start=0, end=100, value=50),
        "victory_disease": pn.widgets.IntSlider(name=f"{prefix}: Victory Disease", start=0, end=100, value=0),
        "micro_management": pn.widgets.IntSlider(name=f"{prefix}: Micro-management", start=0, end=100, value=50),
        "risk_aversion": pn.widgets.IntSlider(name=f"{prefix}: Risk Aversion", start=0, end=100, value=50),
        "fog_of_war_noise": pn.widgets.IntSlider(name=f"{prefix}: Fog of War Noise", start=0, end=100, value=50),
        "black_swan_bias": pn.widgets.IntSlider(name=f"{prefix}: Black Swan Bias", start=0, end=100, value=30),
    }

human_sliders_a = make_human_factor_sliders("A")
human_sliders_b = make_human_factor_sliders("B")

human_card_a = pn.Card("Side A Human Factors", *human_sliders_a.values(), collapsed=True)
human_card_b = pn.Card("Side B Human Factors", *human_sliders_b.values(), collapsed=True)

@pn.depends(
    side_a_conv, side_b_conv, zone_conv,
    chaos_mode, commander_a, commander_b,
    *sliders_a_conv.values(), *sliders_b_conv.values(),
    *human_sliders_a.values(), *human_sliders_b.values(),
)
def update_conv_results():
    s_a = {k: w.value for k, w in sliders_a_conv.items()}
    s_b = {k: w.value for k, w in sliders_b_conv.items()}

    base_results = sim_conventional_war(side_a_conv.value, side_b_conv.value, s_a, s_b, zone_conv.value)
    results = dict(base_results)

    chaos_report = ""
    if chaos_mode.value:
        # Build HumanFactors from sliders (0-100 -> 0-1)
        hf_a = HumanFactors(
            leader_ego=human_sliders_a["leader_ego"].value / 100,
            groupthink=human_sliders_a["groupthink"].value / 100,
            victory_disease=human_sliders_a["victory_disease"].value / 100,
            micro_management=human_sliders_a["micro_management"].value / 100,
            risk_aversion=human_sliders_a["risk_aversion"].value / 100,
            fog_of_war_noise=human_sliders_a["fog_of_war_noise"].value / 100,
            black_swan_bias=human_sliders_a["black_swan_bias"].value / 100,
        )
        hf_b = HumanFactors(
            leader_ego=human_sliders_b["leader_ego"].value / 100,
            groupthink=human_sliders_b["groupthink"].value / 100,
            victory_disease=human_sliders_b["victory_disease"].value / 100,
            micro_management=human_sliders_b["micro_management"].value / 100,
            risk_aversion=human_sliders_b["risk_aversion"].value / 100,
            fog_of_war_noise=human_sliders_b["fog_of_war_noise"].value / 100,
            black_swan_bias=human_sliders_b["black_swan_bias"].value / 100,
        )

        cmd_a = CommanderArchetype[commander_a.value]
        cmd_b = CommanderArchetype[commander_b.value]

        chaos_results = calculate_war_outcome_with_chaos(
            base_results=base_results,
            commander_a=cmd_a,
            commander_b=cmd_b,
            human_factors_a=hf_a,
            human_factors_b=hf_b,
            political_a=PoliticalConstraints(public_war_support=0.6),
            political_b=PoliticalConstraints(public_war_support=0.7),
            enable_black_swans=True,
        )

        # Override some metrics with chaos-adjusted values
        results["nuke_risk"] = chaos_results["chaos_nuke_risk"]
        results["chaos_side"] = chaos_results["chaos_winner_side"]
        results["chaos_reversal"] = chaos_results["chaos_reversal"]
        results["chaos_duration_days"] = chaos_results["chaos_duration_days"]
        results["base_winner"] = chaos_results["base_winner"]
        results["chaos_ratio_after"] = chaos_results["ratio_after"]

        chaos_report = generate_chaos_report(
            chaos_results,
            commander_a_label=commander_a.value,
            commander_b_label=commander_b.value,
        )

    duration_mo = results["duration_days"] / 30.0
    cas_a_k = results["casualties_a"] / 1000
    cas_b_k = results["casualties_b"] / 1000

    summary = f"""
# Conventional War Outcome

**Winner**: {results['winner']}

**Duration**: {results['duration_days']:.0f} days (~{duration_mo:.1f} months)  
**Power Ratio (A:B)**: {results['power_ratio_a_b']}:1  

**Casualties (military)**  
- Side A: {cas_a_k:.0f}k ({results['frac_a']*100:.0f}% of committed)  
- Side B: {cas_b_k:.0f}k ({results['frac_b']*100:.0f}% of committed)  

**Economic Damage (% GDP)**  
- Side A: {results['econ_a_pct']}%  
- Side B: {results['econ_b_pct']}%  

**Regime Collapse Risk**  
- Side A: {results['regime_a']}%  
- Side B: {results['regime_b']}%  

**Nuclear Escalation Risk**: {results['nuke_risk']}%
"""

    if chaos_mode.value and chaos_report:
        summary += chaos_report

    fig = make_subplots(
        rows=2, cols=2,
        subplot_titles=(
            "Military Casualties (thousands)",
            "Economic Damage (% GDP)",
            "Regime Collapse Risk (%)",
            "Force Strength Over Time (thousands)",
        ),
        specs=[[{"type": "bar"}, {"type": "bar"}],
               [{"type": "bar"}, {"type": "xy"}]],
    )

    fig.add_trace(
        go.Bar(x=["Side A", "Side B"], y=[cas_a_k, cas_b_k]),
        row=1, col=1
    )
    fig.add_trace(
        go.Bar(x=["Side A", "Side B"], y=[results["econ_a_pct"], results["econ_b_pct"]]),
        row=1, col=2
    )
    fig.add_trace(
        go.Bar(x=["Side A", "Side B"], y=[results["regime_a"], results["regime_b"]]),
        row=2, col=1
    )
    fig.add_trace(
        go.Scatter(x=results["times"], y=results["strengths_a"], mode='lines', name='Side A'),
        row=2, col=2
    )
    fig.add_trace(
        go.Scatter(x=results["times"], y=results["strengths_b"], mode='lines', name='Side B'),
        row=2, col=2
    )

    fig.update_layout(height=700, showlegend=False, title_text="Conventional War Dynamics")

    return pn.Column(pn.pane.Markdown(summary), pn.pane.Plotly(fig))


conv_tab = pn.Column(
    pn.pane.Markdown("## Conventional War – Conflict Lab"),
    pn.Row(side_a_conv, side_b_conv),
    pn.Row(zone_conv),
    pn.Row(chaos_mode),
    pn.Row(commander_a, commander_b),
    pn.Row(human_card_a, human_card_b),
    pn.Row(
        pn.Column("### Side A Parameters", *sliders_a_conv.values()),
        pn.Column("### Side B Parameters", *sliders_b_conv.values()),
    ),
    update_conv_results,
)


# --- UI: Economic warfare tab ---

side_a_econ = pn.widgets.MultiChoice(
    name="Sanctioning Coalition (Side A)",
    options=list(COUNTRIES.keys()),
    value=["USA"],
)
side_b_econ = pn.widgets.MultiChoice(
    name="Target (Side B)",
    options=list(COUNTRIES.keys()),
    value=["Russia"],
)

econ_sliders_s = {
    "CoalitionLeverage": pn.widgets.IntSlider(
        name="A: Coalition Leverage (political & institutional)", start=0, end=100, value=70
    ),
    "EnforcementIntensity": pn.widgets.IntSlider(
        name="A: Enforcement Intensity", start=0, end=100, value=75
    ),
    "FinancialPenetration": pn.widgets.IntSlider(
        name="A: Financial Penetration", start=0, end=100, value=80
    ),
    "TimeHorizonMonths": pn.widgets.IntSlider(
        name="Time Horizon (months)", start=6, end=120, step=6, value=36
    ),
}

econ_sliders_t = {
    "Resilience": pn.widgets.IntSlider(
        name="B: Resilience (domestic + structural)", start=0, end=100, value=60
    ),
    "AltMarkets": pn.widgets.IntSlider(
        name="B: Alternative Markets / Partners", start=0, end=100, value=50
    ),
}

@pn.depends(side_a_econ, side_b_econ,
           *econ_sliders_s.values(), *econ_sliders_t.values())
def update_econ_results():
    s_s = {k: w.value for k, w in econ_sliders_s.items()}
    s_t = {k: w.value for k, w in econ_sliders_t.items()}

    results = sim_economic_war(side_a_econ.value, side_b_econ.value, s_s, s_t)

    summary = f"""
# Economic Warfare / Sanctions Outcome

**Sanctioning Coalition GDP**: ${results['coalition_gdp']:.1f}T  
**Target GDP**: ${results['target_gdp']:.1f}T  

**Effective Coalition Leverage**: {results['coalition_leverage']*100:.0f}%  
**Target Structural Resilience**: {results['resilience']*100:.0f}%  

**Target GDP Loss over {results['time_years']:.1f} years**: {results['target_damage_pct']}%  
**Coalition Blowback (GDP Loss)**: {results['coalition_damage_pct']}%  

**Target Regime Stress**: {results['target_regime_stress']}%  
**Sanctions Success Probability (coercing major concession)**: {results['sanctions_success_prob']}%
"""

    fig = make_subplots(
        rows=1, cols=3,
        subplot_titles=(
            "GDP Loss (%)",
            "Regime Stress / Success",
            "Resilience vs Leverage",
        ),
        specs=[[{"type": "bar"}, {"type": "bar"}, {"type": "bar"}]],
    )

    fig.add_trace(
        go.Bar(x=["Target", "Coalition"],
               y=[results["target_damage_pct"], results["coalition_damage_pct"]]),
        row=1, col=1
    )
    fig.add_trace(
        go.Bar(x=["Regime Stress", "Success Prob"],
               y=[results["target_regime_stress"], results["sanctions_success_prob"]]),
        row=1, col=2
    )
    fig.add_trace(
        go.Bar(x=["Resilience", "Leverage"],
               y=[results["resilience"]*100, results["coalition_leverage"]*100]),
        row=1, col=3
    )

    fig.update_layout(height=450, showlegend=False, title_text="Economic Warfare Dynamics")

    return pn.Column(pn.pane.Markdown(summary), pn.pane.Plotly(fig))


econ_tab = pn.Column(
    pn.pane.Markdown("## Economic Warfare / Sanctions – Conflict Lab"),
    pn.Row(side_a_econ, side_b_econ),
    pn.Row(
        pn.Column("### Sanctioning Coalition (A)", *econ_sliders_s.values()),
        pn.Column("### Target (B)", *econ_sliders_t.values()),
    ),
    update_econ_results,
)

# --- Tabs & serve ---

tabs = pn.Tabs(
    ("Conventional War", conv_tab),
    ("Economic Warfare", econ_tab),
)

tabs.servable()
